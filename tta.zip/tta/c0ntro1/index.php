<?php
session_start();
include "../inc/conn.php";

//mysql_query("set session character_set_connection=euckr;");
//mysql_query("set session character_set_results=euckr;");
//mysql_query("set session character_set_client=euckr;");

if($_SESSION[id]!="admin")
{
	header("HTTP/1.0 404 Not Found");
	exit();
}

header("Content-Type: text/html;charset=euc-kr");

$token=token_make();

if($_POST[token])
{
	token_check($_POST[token]);	
}

?>
<!DOCTYPE html>
<html>
<head>
<title>admin page</title>
<link rel="stylesheet" type="text/css" href="../css/style.css">
<script type="text/javascript" src="../js/comm.js"></script>
</head>
<body onUnload=unload_check();>
<?php echo("<div align=right><font size=2 color=green>".date('H:i:s')." $_SERVER[REMOTE_ADDR]</font></div>"); ?>
	<div id=menu style=padding:10pt;>
		<div onclick=location.href='?m=1' style=width:10%>Members</div>
                <div onclick=location.href='?m=2' style=width:10%>Challenges</div>
                <div onclick=location.href='?m=6' style=width:10%>Category</div>
                <div onclick=location.href='?m=3' style=width:10%>Board</div>
                <div onclick=location.href='?m=4' style=width:10%>Notice</div>
                <div onclick=location.href='?m=5' style=width:10%>Calendar</div>
                <div onclick=location.href='?m=7' style=width:10%>Log</div>
                <div onclick=location.href='?m=8' style=width:10%>Contact</div>
                <div onclick=location.href='?m=9' style=width:10%>Admin</div>
	</div>
<br>
	<div id=msg style=width:90%>
	<?php
		if($_GET[m]==1)
		{
			if($_GET[del])
			{
				user_check($_GET[del]);

				if($_GET[del]!="admin")
				{
					if($_POST[id]==$_GET[del])
					{
						@mysql_query("delete from tbl_user where reg_id='$_GET[del]'");
						exit("<meta http-equiv=refresh content=0;url='?m=1'>");

					}
					echo("<center>���� ".htmlspecialchars($_GET[del])." ���̵� �����ұ��?");
					echo("<form method=post action='index.php?m=1&del=$_GET[del]'><input type=hidden name=token value='$token'><input type=hidden name=id value='$_GET[del]'><input type=submit 
value='����'><input 
type=button value='���ư���' onclick=location.href='index.php?m=1'></form></center>");
					exit();
				}
			}

			$order="reg_join";
			if($_GET[order]=="reg_id" || $_GET[order]=="reg_ip" || $_GET[order]=="reg_cash" || $_GET[order]=="reg_join") $order=$_GET[order];
			echo("<table border=1 align=center cellpadding=10 cellspacing=0><tr><td>no</td><td><a 
href='?m=1&order=reg_id'>reg_id</a></td><td><a href='?m=1&order=reg_ip'>reg_ip</a></td><td>reg_email</td><td><a href='?m=1&order=reg_cash'>reg_cash</a></td><td><a 
href='?m=1&order=reg_join'>reg_join</a></td><td>reg_cmt</td><td>action</td></tr>");
			$limit=1;
			if($_GET[page]) $limit=$_GET[page];
			$limit=($limit*10)-10;
			$q=mysql_query("select * from tbl_user order by $order asc limit $limit,10");
			$i=1;
			while($d=mysql_fetch_array($q))
			{
				$d[reg_email]=htmlspecialchars($d[reg_email]);
				$d[reg_id]=htmlspecialchars($d[reg_id]);
				$d[reg_cmt]=htmlspecialchars($d[reg_cmt]);
				$d[reg_cash]=number_format($d[reg_cash]);
				$d[reg_join]=date('Y-m-d H:i:s',$d[reg_join]);
				echo("<tr align=center><td>$i</td><td>$d[reg_id]</td><td>$d[reg_ip]</td><td>$d[reg_email]</td><td>$d[reg_cash]</td><td>$d[reg_join]</td><td>$d[reg_cmt]</td><td><input type=button 
value='DEL' onclick=location.href='?m=1&del=$d[reg_id]'><input type=button value='BLOCK' onclick=location.href='?m=1&block=$d[reg_ip]'></tr>");
				$i++;

			}
			echo("<tr><td colspan=8 style=background:gray;text-align:center>");
			$cnt=@mysql_fetch_array(mysql_query("select count(1) from tbl_user"));
			$page=ceil($cnt[0]/10);
			for($i=$page;$i>0;$i--) if($i==$_GET[page]) echo("[<font color=silver>$i</font>]"); else echo("[<a href=?m=1&page=$i style=color:black>$i</a>] ");
			echo("</td></tr></table>");
		}

		if($_GET[m]==2)
		{

			if($_POST[p_name] && $_POST[p_type] && $_POST[p_score] && $_POST[p_page] && $_POST[p_discription] && $_POST[p_flag])
			{
				$_POST[p_name]=sql_guard($_POST[p_name]);
                                $_POST[p_page]=sql_guard($_POST[p_page]);
                                $_POST[p_discription]=sql_guard($_POST[p_discription]);
                                $_POST[p_flag]=sql_guard($_POST[p_flag]);

				$_POST[p_name]=htmlspecialchars($_POST[p_name]);
                                $_POST[p_discription]=htmlspecialchars($_POST[p_discription]);
                                $_POST[p_page]=htmlspecialchars($_POST[p_page]);
                                $_POST[p_flag]=htmlspecialchars($_POST[p_flag]);


				if($_POST[p_type]!="sql" && $_POST[p_type]!="xss" && $_POST[p_type]!="fi" && $_POST[p_type]!="fu" && $_POST[p_type]!="code" && $_POST[p_type]!="etc" && $_POST[p_type]!="hidden")
				{
//					exit("</div><div id=error>p_type error</div>");
				}

				if(eregi("[^0-9]",$_POST[p_score])) exit("</div><div id=error>p_score error</div>");

				if($_GET[add]==1)
				{
			$prob_name_check=@mysql_fetch_array(mysql_query("select reg_name from tbl_probs where reg_name='$_POST[p_name]'"));
				if($prob_name_check[reg_name]) { echo("reg_name error"); exit(); }
					$cnt=@mysql_fetch_array(mysql_query("select count(1) from tbl_probs"));
					$cnt=$cnt[0]+1;
					$check=@mysql_fetch_array(mysql_query("select reg_prob".$cnt." from tbl_user_probs"));
					if($check[0]=="")
					{
						@mysql_query("alter table tbl_user_probs add column reg_prob".$cnt." int(50);");
						@mysql_query("update tbl_user_probs set reg_prob".$cnt."=0");
					}
					@mysql_query("insert into tbl_probs values('$cnt','$_POST[p_name]','$_POST[p_type]','$_POST[p_score]','$_POST[p_page]','$_POST[p_discription]','$_POST[p_flag]')");
				}

				if($_GET[modify])
				{

					if(eregi("[^0-9]",$_GET[modify])) exit("</div><div id=error>reg_no error</div>");
					$ck=@mysql_fetch_array(mysql_query("select reg_no from tbl_probs where reg_no='$_GET[modify]'"));
					if($ck[reg_no]!=$_GET[modify]) exit("</div><div id=error>reg_no error</div>");
					@mysql_query("update tbl_probs set reg_name='$_POST[p_name]' where reg_no='$ck[reg_no]'");
                                        @mysql_query("update tbl_probs set reg_type='$_POST[p_type]' where reg_no='$ck[reg_no]'");
                                        @mysql_query("update tbl_probs set reg_score='$_POST[p_score]' where reg_no='$ck[reg_no]'");
                                        @mysql_query("update tbl_probs set reg_page='$_POST[p_page]' where reg_no='$ck[reg_no]'");
                                        @mysql_query("update tbl_probs set reg_discription='$_POST[p_discription]' where reg_no='$ck[reg_no]'");
                                        @mysql_query("update tbl_probs set reg_flag='$_POST[p_flag]' where reg_no='$ck[reg_no]'");

				}


			}

$cate=mysql_query("select reg_type from tbl_probs_category");
$cate2=mysql_query("select reg_type from tbl_probs_category");

//while($cate_

			echo("<table border=1 cellpadding=10 cellspacing=0 
style=width:100%><tr><td>reg_no</td><td>reg_name</td><td>reg_type</td><td>reg_score</td><td>reg_page</td><td>reg_discription</td><td>reg_flag</td></tr>\n");
			$q=mysql_query("select * from tbl_probs order by reg_no asc");
			$i=1;
			while($d=mysql_fetch_array($q))
			{
				$d[reg_score]=number_format($d[reg_score]);
				echo("
					<form method=post action='?m=2&modify=$d[reg_no]' onsubmit=\"ck=confirm('[$d[reg_no]] $d[reg_name]');if(ck!=true)return false;\">
					<tr>
						<td>$d[reg_no]</td>
						<td><input type=text name=p_name value='$d[reg_name]'></td>
						<td>
							<select name=p_type>");
							$cate2=mysql_query("select reg_type from tbl_probs_category");

							while($cate_dd=mysql_fetch_array($cate2))
							{
                                                        	echo("<option value='$cate_dd[reg_type]'");if($d[reg_type]=="$cate_dd[reg_type]"){echo("selected ");}echo(">$cate_dd[reg_type]</option>");

							}
							echo("<!--
	                                                <option value='sql'");if($d[reg_type]=="sql"){echo("selected ");}echo(">sql</option>
	                                                <option value='xss'");if($d[reg_type]=="xss"){echo("selected ");}echo(">xss</option>
	                                                <option value='fi'");if($d[reg_type]=="fi"){echo("selected ");}echo(">fi</option>
        	                                        <option value='fu'");if($d[reg_type]=="fu"){echo("selected ");}echo(">fu</option>
                	                                <option value='code'");if($d[reg_type]=="code"){echo("selected ");}echo(">code</option>
                        	                        <option value='etc'");if($d[reg_type]=="etc"){echo("selected ");}echo(">etc</option>-->
                                                        <option value='hidden'");if($d[reg_type]=="hidden"){echo("selected ");}echo(">HIDDEN</option>

						</td>
                                                </select>

						<td><input type=text name=p_score value='$d[reg_score]' size=5></td>
						<td><input type=text name=p_page value='$d[reg_page]'></td>
						<td><input type=text name=p_discription value='$d[reg_discription]' size=30></td>
						<td><input type=text name=p_flag value='$d[reg_flag]'><input type=submit value='Modify'></td>
					</tr>
					</form>\n");
				$i++;
			}

			echo("
				<form method=post action='?m=2&add=1'>
				<tr>
					<td>$i</td>
					<td><input type=text name=p_name></td>
					<td>
						<select name=p_type>");
						while($cate_d=mysql_fetch_array($cate)) echo("<option value='$cate_d[reg_type]'>$cate_d[reg_type]</option>");
echo("
<!--
						<option value='sql'>sql</option>
                                                <option value='xss'>xss</option>
                                                <option value='fi'>fi</option>
                                                <option value='fu'>fu</option>
                                                <option value='code'>code</option>
                                                <option value='etc'>etc</option>
-->
                                                <option value='hidden' selected>HIDDEN</option>

						</select>
					</td>

					<td><input type=text name=p_score size=5></td>
					<td><input type=text name=p_page value='challenges/'></td>
					<td><input type=text name=p_discription size=30></td>
					<td><input type=text name=p_flag><input type=submit value='Add'></td>

				</tr>
				
			");


		}

		if($_GET[m]==3)
		{
			if($_GET[del])
			{
				if(eregi("[^0-9]",$_GET[del])) exit("<div id=error>Access Denied</div>");
				@mysql_query("delete from tbl_board where no='$_GET[del]'");
			}

			echo("<table border=1 align=center style=width:100%><tr><td>reg_no</td><td>reg_id</td><td>reg_sub</td><td colspan=2>reg_content</td></tr>");

			$q=mysql_query("select * from tbl_board order by no desc");
			while($d=mysql_fetch_array($q))
			{
				$d[sub]=html_($d[sub]);
				$d[memo]=html_($d[memo]);
				echo("<tr><td width=50>$d[no]</td><td>$d[name]</td><td>$d[sub]</td><td>$d[memo]</td><td width=50><input type=button value='REMOVE' onclick=\"if(this.value=='REMOVE'){this.style.background='pink';this.value='Really?';return false;}location.href='?m=3&del=$d[no]'\"></td></tr>");
			}
			echo("</table>");
		}


		if($_GET[m]==4)
		{

			if($_GET[modify])
                        {
                        	if(eregi("[^0-9]",$_GET[modify])) exit("<div id=error>Access Denied</div>");

				if($_POST['sub'] && $_POST['content'])
				{
					$q=mysql_fetch_array(mysql_query("select reg_time from tbl_admin_notice where reg_time='$_GET[modify]'"));
					if($q)
					{
						@mysql_query("update tbl_admin_notice set reg_sub='$_POST[sub]' where reg_time='$_GET[modify]'");
                                                @mysql_query("update tbl_admin_notice set reg_content='$_POST[content]' where reg_time='$_GET[modify]'");
					}
				}

                                $q=mysql_fetch_array(mysql_query("select * from tbl_admin_notice where reg_time='$_GET[modify]'"));
				$q[reg_sub]=str_replace("<","&lt;",$q[reg_sub]);
				$q[reg_content]=str_replace("</textarea>","&lt;/textarea>",$q[reg_content]);

				echo("<form method=post action='?m=4&modify=$_GET[modify]'><table border=1 align=center width=100%><tr align=center><td width=50>����</td><td><input type=text name=sub style=width:99% value='$q[reg_sub]'></td></tr><tr align=center><td>����</td><td><textarea name=content rows=20 style=width:99%;height:100%>$q[reg_content]</textarea></td></tr><tr><td colspan=2 align=center><input type=button value='���ư���' onclick=location.href='?m=4'><input type=submit></td></tr></table></form>");
				exit();
			}

			if($_GET[mode]=="write")
			{

				if($_POST[sub] && $_POST[content])
				{
					$tm=time();
					@mysql_query("insert into tbl_admin_notice values('$tm','$_POST[sub]','$_POST[content]')");
					echo("<div id=msg>��� �Ϸ�</div>");
					exit("<meta http-equiv=refresh content=1;url='?m=4'>");
				}

				echo("<form method=post action='?m=4&mode=write'><table border=1 align=center width=100%><tr align=center><td width=50>����</td><td><input type=text name=sub 
style=width:99%></td></tr><tr align=center><td>����</td><td><textarea 
name=content rows=20 style=width:99%;height:100%></textarea></td></tr><tr><td colspan=2 align=center><input type=button value='���ư���' onclick=location.href='?m=4'><input type=submit></td></tr></table></form>");
			exit();
			}

			if($_GET[remove])
			{
				if(eregi("[^0-9]",$_GET['remove'])) exit("<div id=error>Access Denied</div>");
				$q=mysql_fetch_array(mysql_query("select reg_time from tbl_admin_notice where reg_time='$_GET[remove]'"));
				if($q) @mysql_query("delete from tbl_admin_notice where reg_time='$_GET[remove]'");
			}


			$q=mysql_query("select * from tbl_admin_notice order by reg_time desc");

			echo("<table border=1 align=center width=100%><tr><td width=150>reg_time</td><td colspan=2>reg_sub</td></tr>");

			while($d=mysql_fetch_array($q))
			{
				echo("<tr><td>".date('Y-m-d',$d['reg_time'])."</td><td>$d[reg_sub]</td></td><td width=150><input type=button value='Modify' onclick=location.href='?m=4&modify=$d[reg_time]'><input type=button value='REMOVE' onclick=\"if(this.value=='REMOVE'){this.style.background='pink';this.value='Really?';return false;}location.href='?m=4&remove=$d[reg_time]'\"></td></tr>");
			}
			echo("</table><br><center><input type=button value='���' onclick=location.href='?m=4&mode=write'></center>");

		}

		if($_GET[m]==6)
		{

			if($_GET[mode]=="del" && $_GET[type])
			{
				$ck=mysql_fetch_array(mysql_query("select reg_type from tbl_probs where reg_type='$_GET[type]'"));
				if($ck) exit("�ش� ī�װ����� ������ �����մϴ�. ī�װ����� �����ϱ� ���� ������ �������ּ���.");
				mysql_query("delete from tbl_probs_category where reg_type='$_GET[type]'");
				echo("Done!");
			}

			if($_POST[add_type] && $_POST[add_des])
			{
				mysql_query("insert into tbl_probs_category values('$_POST[add_type]','$_POST[add_des]')");
				echo("Done!");
			}

			$q=mysql_query("select * from tbl_probs_category");
			echo("<form method=post action=?m=6><table border=1 cellpadding=10 style=width:100%>");
			echo("<tr><td>reg_type</td><td>reg_description</td><td>&nbsp;</td></tr>");
			while($d=mysql_fetch_array($q))
			{
				$d[reg_type]=htmlspecialchars($d[reg_type]);
				$d[reg_description]=htmlspecialchars($d[reg_description]);

				echo("<form method=post action=?m=6><tr><td><input type=text value='".$d[reg_type]."' name=modify_type></td><td><input type=text value='".$d[reg_description]."' name=modify_des></td><td>
<input type=button value='REMOVE' onclick=location.href='?m=6&mode=del&type=$d[reg_type]' style=background:#F15F5F;></td></tr>");
			}
			echo("<tr align=center><td><input type=text name=add_type style=width:100%></td><td><input type=text name=add_des style=width:100%></td><td><input type=submit></td></tr>");
			
			echo("</table>");
		}


		if($_GET[m]==5)
		{
                        $m=date('m',time());
			if($m<10) $m=str_replace("0","",$m);

			if($_GET[mode]=="write" && $_POST[date] && $_POST[val])
			{
				$_POST[date]=addslashes($_POST[date]);
				$_POST[val]=str_replace("<","&lt;",$_POST[val]);		
				$_POST[val]=addslashes($_POST[val]);
//				$_POST[val]=iconv("euc-kr","utf-8",$_POST[val]);
				$month = date('m');
				mysql_query("insert into tbl_calendar(m,d,val) values('$month','$_POST[date]','$_POST[val]')") or die("error");
				echo("Done<meta http-equiv=refresh content=1;url=?m=5>");
				exit();
			}


			if($_GET[mode]=="modify" && $_POST[d] && $_POST[val])
			{
				$_POST[d]=addslashes($_POST[d]);
				$_POST[val]=addslashes($_POST[val]);

				$ck=mysql_fetch_array(mysql_query("select * from tbl_calendar where m='$m' and d='$_POST[d]'"));

				if($ck)
				{
					@mysql_query("update tbl_calendar set d='$_POST[d]' where m='$ck[m]' and d='$ck[d]'");
                                        @mysql_query("update tbl_calendar set val='$_POST[val]' where m='$ck[m]' and d='$ck[d]'");
				}

			}

			if($_GET[del] && $_GET[val])
			{
				$_GET[del]=addslashes($_GET[del]);
				$_GET[val]=addslashes($_GET[val]);

				$ck=mysql_fetch_array(mysql_query("select * from tbl_calendar where m='$m' and d='$_GET[del]' and val='$_GET[val]'"));

				if($ck) @mysql_query("delete from tbl_calendar where m='$ck[m]' and d='$ck[d]' and val='$ck[val]'");

			}

			$q=mysql_query("select * from tbl_calendar where m='$m'");

			echo("<table border=1 align=center style=width:100%>");

			while($d=mysql_fetch_array($q))
			{
				$d[d]=htmlspecialchars($d[d]);
				$d[val]=htmlspecialchars($d[val]);
				echo("<form method=post action='?m=5&mode=modify'><tr><td width=50><input style=width:100%; type=text name=d value='$d[d]'></td><td><input style=width:100%; type=text name=val 
value='$d[val]'></td><td align=center width=200><input type=submit value='Modify'><input type=button value='Remove' style=background:pink; onclick=\"ck=confirm('Really?');if(ck!=true)return 
false;location.href='?m=5&del=$d[d]&val=$d[val]'\"></form></tr>");			
			}

			echo("</table><br><br><form method=post action='?m=5&mode=write'>Day : <input type=text name=date value=".date('d',time())."><br>value : <input type=text name=val><br><input type=submit></form>");
		}

		if($_GET[m]==7)
		{
			$log=@file("LOG/log.php") or die("error");

			echo("<form method=get action=index.php><input type=hidden name=m value=7><input type=text style=width:90% name=find><input type=submit><br></form><input type=button onclick=location.href='?m=7&find=c_flag' value='�����α�'>");

			echo("<div style=overflow:scroll;width:100%;height:500pt;font-size:10pt;>");

			for($i=count($log);$i>0;$i--)
			{
				$para=strstr($log[$i]," [p] ");
				$para=str_replace(" [p] ","",$para);
				$result[$i]=$log[$i]."<br>";
			}

			for($i=count($result);$i>0;$i--)
			{
				$log_id=strstr($result[$i],"]");
				$log_id=str_replace(strstr($log_id,"("),"",$log_id);
				$log_id=substr($log_id,1);
				$result[$i]=str_replace($log_id,"<a href='?m=7&find=$log_id'>$log_id</a>",$result[$i]);
				if(!eregi("c0ntro1/index.php",$result[$i]) && !eregi("$_SERVER[REMOTE_ADDR]",$result[$i]) && !$_GET[find]) $print.=$result[$i]."\n";
				if(isset($_GET['find']) && !$_POST['find'] && eregi("$_GET[find]",$result[$i])) $print.=$result[$i]."\n";
			}

			echo("��ü �α� : ".number_format(count($result))."��<br>");
			$page=explode("\n",$print);
			echo("��µ� ��� : ".number_format(count($page)-1)."��<br>");

			$page_cnt=ceil(count($page)/100);

			if($_GET[page]) echo("[<a href=?m=7&find=$_GET[find]>��ü</a>] ");
			if(!$_GET[page]) echo("[��ü] ");

			for($i=1;$i<=$page_cnt;$i++)
			{
				if($_GET[page]!=$i) echo("[<a href=?m=7&page=$i&find=$_GET[find]>$i</a>] ");
				if($_GET[page]==$i) echo("[$i] ");
			}

			echo("<br>");

			if(!$page_input) $page_input=0;
			if($_GET[page])	$page_input = ($_GET[page]*100)-100;

			for($i=$page_input;$i<count($page);$i++) echo($page[$i]);

			echo("</div>");
		}

		if($_GET[m]==9)
		{
			if($_POST[change_pw] && $_POST[confirm_pw])
			{
				$get_admin_pw=@mysql_fetch_array(mysql_query("select reg_pw from tbl_user where reg_id='admin' limit 1"));
				if($get_admin_pw[0]!=md5($_POST[confirm_pw])) echo("���� �н����尡 ��ġ���� �ʽ��ϴ�");
				else
				{
					$change_pw=md5($_POST[change_pw]);
					mysql_query("update tbl_user set reg_pw='$change_pw' where reg_id='admin'") or die(mysql_error());
					$_SESSION[id]="";
					echo("�н����尡 ����Ǿ����ϴ�.<br><br>�α��� ���ּ���");
					exit();
				}
			}

		else
			echo("<div align=center style=padding:10pt;>
<form method=post action='?m=9'>
<table border=0 cellpadding=10><tr><td><input type=hidden name=token value='$token'>���� �н�����</td><td><input type=password name=confirm_pw></td></tr>
<tr><td>������ �н�����</td><td><input type=password name=change_pw></td></tr><tr><td colspan=2 align=center><input type=submit></td></tr></table></form><br></div>");

		}

		if($_GET[m]==8)
		{

			if($_GET[reply] && $_GET[reply_id])
			{
				if(eregi("[^0-9]",$_GET[reply])) exit("<div id=error>Access Denied</div>");
				$q=mysql_fetch_array(mysql_query("select * from tbl_admin_contact where reg_id='$_GET[reply_id]' and reg_time='$_GET[reply]'"));
				if($q)
				{

					if($_POST[reply])
					{
						$tm=time();
						@mysql_query("insert into tbl_user_msg values('$tm','$q[reg_id]','admin','$_POST[reply]',0,0)");
						@mysql_query("delete from tbl_admin_contact where reg_time='$_GET[reply]' and reg_id='$_GET[reply_id]'");
						exit("<meta http-equiv=refresh content=0;url='?m=8'>");
					}

					$q[reg_content]=str_replace("<","&lt;",$q[reg_content]);
					echo("<table border=0 align=center style=width:100%><tr align=center><td>$q[reg_id]</td></tr><tr><td bgcolor=silver>? $q[reg_content]</td></tr><tr align=center><td><hr>admin</td></tr><tr align=center bgcolor=silver><td><form method=post action='?m=8&reply=$_GET[reply]&reply_id=$_GET[reply_id]'><input type=text name=reply style=background:silver;width:95%;border:0 value='�亯: '><input type=submit></form></td></tr><tr><td colspan=2 align=center><br><br><input type=button value='���ư���' onclick=location.href='?m=8'></td></tr></table>");
				exit();
				}
			}

			if($_GET[remove] && $_GET[remove_id])
			{
				if(eregi("[^0-9]",$_GET[remove])) exit("<div id=error>Access Denied</div>");
				$q=mysql_fetch_array(mysql_query("select reg_time from tbl_admin_contact where reg_id='$_GET[remove_id]' and reg_time='$_GET[remove]'"));
				if($q) @mysql_query("delete from tbl_admin_contact where reg_time='$_GET[remove]' and reg_id='$_GET[remove_id]'");
			}

			$q=mysql_query("select * from tbl_admin_contact order by reg_time desc limit 0,20");

			echo("<table border=1 align=center cellpadding=5 style=width:100%>");
			echo("<tr align=center><td width=200>reg_time</td><td width=200>reg_cate</td><td>reg_id</td><td colspan=2>reg_content</td></tr>");
			while($d=mysql_fetch_array($q))
			{
				if($d['reg_cate']==1) $d['reg_cate']="�̿� ����";
	                        if($d['reg_cate']==2) $d['reg_cate']="����/����� ����";
                                if($d['reg_cate']==3) $d['reg_cate']="��Ÿ";

				echo("<tr><td>".date('Y-m-d H:i:s',$d['reg_time'])."</td><td>".$d['reg_cate']."</td><td>".$d['reg_id']."</td><td>".$d['reg_content']."</td><td><input type=button value='Reply' onclick=location.href='?m=8&reply=$d[reg_time]&reply_id=$d[reg_id]'><input type=button value='REMOVE' onclick=\"if(this.value=='REMOVE'){this.value='Really?';return false;}location.href='?m=8&remove=$d[reg_time]&remove_id=$d[reg_id]'\"></td></tr>");
			}
			echo("</table>");
		}

	?>
	</div>


</body>
</html>