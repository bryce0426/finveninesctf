<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Admin page</title>
</head>
<body>
<?php
	mysql_connect("localhost","admin_page","admin_page") or die("* mysql_connect error");
	mysql_select_db("admin_page");
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_unionadmin!");
?>
<div id=all>
	<h1>S<span style="font-size:150px;color:#c38743;">ystem</span></h1>
	<form method=get action=index.php>
	<h2>Admin page login</h2>
	<div class=text>
<?php
if($_GET[id] && $_GET[pw])
{
	$q=mysql_fetch_array(mysql_query("select * from mem where id='$_GET[id]' and pw='$_GET[pw]'"));

	if($q[id])
	{
		echo("[*] hi! ".htmlspecialchars($q[id])."<br>");
		if($q[pw]!=$_GET[pw]) echo("[*] <u>Wrong password</u><br>");

		if($q[pw]==$_GET[pw])
		{
			echo("[*] Login success!<br>");
			if($q[id]=="admin")echo("[*] <b>Password is $password</b><br>");
		}
	}

}
else echo("<input type=text name=id size=30 value=guest><input type=password name=pw size=30 value=guest><input type=submit>");
?>

		</form>
	</div>
</div>
</body>
</html>
