<?php
if($_GET[refresh]==1)
{
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_ezXSSchal1enGE");
	echo("Password is $password");
}

?>
