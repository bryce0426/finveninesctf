<?php 
session_start();
header('X-XSS-Protection: 0');


if(!$_GET[token])
{
	exit("ACCESS DENIED");
}

if($_GET[token])
{
	for($i=time()-60;$i<=time();$i++)
	{
		$token = sha1("$_SERVER[REMOTE_ADDR]_hehe!sheshe2".$i);
		if($_GET[token]==$token) $check="true";
	}

	if($check!="true") exit("ACCESS DENIED");

}

if(!$_SESSION[xss_challenge])
{
	$_SESSION[xss_challenge]=1;
	exit("<meta http-equiv=refresh content=0;url=game.php>");
}

if($_GET[refresh]==1) exit("<meta http-equiv=refresh content=0;url=game.php>"); ?>
<html>
<head>
<link rel="stylesheet" href="style.css" type="text/css">
<script src="script.js"></script>
<title>Basic XSS</title>
</head>
<body>
<?php
if(!$_POST[name])
{
echo("
<form method=post action=game.php?token=$token>
<table border=1 cellpadding=10>
<tr><td>name</td><td><input type=text name=name></td></tr>
<tr><td colspan=2 align=center><input type=submit></td></tr>
</table>
</form>
");
}

if($_POST[name])
{
	if(eregi("script|expre",$_POST[name])) exit("Access Denied");
	$_POST[name]=htmlspecialchars($_POST[name]);
	echo("<script>var show_name='$_POST[name]'; document.write('hi! '+show_name);</script><br><br>");
}

?>
</body>
</html>
