eval(function (p, a, c, k, e, r) {
    e = function (c) {
        return c.toString(a)
    };
    if (!''.replace(/^/, String)) {
        while (c--) r[e(c)] = k[c] || e(c);
        k = [

            function (e) {
                return r[e]
            }
        ];
        e = function () {
            return '\\w+'
        };
        c = 1
    };
    while (c--)
        if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
    return p
}('d 4=0.2;0.2=a(c){4("3!");e.8.9="<7 b=5.6?3=1>";f("g.h=\'5.6?i=1\'",j)}', 20, 20, 
'window||alert|clear|quddkfl|clear|php|img|body|innerHTML|function|src|quddkfle|var|document|setTimeout|location|href|50|100'.split('|'), 0, {}))
