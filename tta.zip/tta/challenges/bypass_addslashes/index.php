<?php
session_start();
?>
<html>
<head>
<style type="text/css">
body { background:#EAEAEA; color:#484848; font-size:11pt; line-height:100%; }
p { background:silver; height:20pt;text-align:center; margin:10pt; padding:10pt; font-size:20pt; font-weight:bold;}
table { width:50%; padding:20pt; }
input[type=text] { width:100%; background:#EAEAEA; }
input[type=text]:hover { background:white; }
input[type=submit] { width:100pt;}
input[type=submit]:hover { border:1pt solid black; }
</style>
<title>Bypass_addslashes</title>
</head>
<body>
<p>Bypass addslashes</p>
<?php

mysql_connect("localhost","bypass","bypass");
mysql_select_db("bypass");

foreach($_POST as $no=>$val) $_POST[$no]=addslashes($val);

$cnt=@mysql_fetch_array(mysql_query("select count(id) from mem"));
if($cnt[0]>=10000) mysql_query("delete from mem");

if($_SESSION[bypass_id])
{
	if($_GET[logout]==1)
	{
		$_SESSION[bypass_id]="";
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	$q=@mysql_fetch_array(mysql_query("select id from mem where id='$_SESSION[bypass_id]' and ip='$_SERVER[REMOTE_ADDR]'"));
	if(!$q) exit("Access Denied<meta http-equiv=refresh content=1;url=index.php?logout=1>");
	echo("hi! ".htmlspecialchars($q[id])."<br><br><a href=?logout=1>Logout</a><br>");
	exit();

}

if($_POST[cmd] && $_POST[id] && $_POST[pw] && !$_SESSION[bypass_id])
{
        $q=@mysql_fetch_array(mysql_query("select id,pw from mem where id='$_POST[id]'"));
	if($_POST[cmd]=="Login" && $q[id] && $q[pw]==$_POST[pw])
	{
		$_SESSION[bypass_id]=$q[id];
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	if($_POST[cmd]=="Register" && !$q[id])
	{
		@mysql_query("insert into mem(id,pw,ip) values('$_POST[id]','$_POST[pw]','$_SERVER[REMOTE_ADDR]')")or die("error");
		exit("Done!<meta http-equiv=refresh content=1;url=index.php>");
	}
}
?>
<form method=post action=index.php>
<table border=0 align=center cellpadding=10 cellspacing=0>
<tr><td width=100>user_id</td><td><input type=text name=id></td></tr>
<tr><td width=100>user_pw</td><td><input type=text name=pw></td></tr>
<tr><td colspan=2 align=center><input type=submit name=cmd value='Login'>
<input type=submit name=cmd value='Register'></td></tr>
</table>
</form>
<a href=index.phps>index.phps</a>
</body>
</html>
