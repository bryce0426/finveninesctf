<?php
@session_start();

if($_GET[login_ok])
{
	if($_GET[login_ok]==md5("guest"))
	{
		$_SESSION[control_id]="guest";
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	if($_GET[login_ok]==md5("admin"))
	{
		$_SESSION[control_id]="admin";
                exit("<meta http-equiv=refresh content=0;url=index.php>");

	}
}

if($_SESSION[control_id])
{
	if($_GET[mode]=="logout") { $_SESSION[control_id]=""; exit("<meta http-equiv=refresh content=0;url=index.php>"); }
	echo("hi! $_SESSION[control_id]<br><br><a href=?mode=logout>logout</a><br>");

	if($_SESSION[control_id]=="admin")
	{
	        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_pArAmEtErCoNtRo1");
		echo("Password is $password");
	}

	exit();
}

?>
<html>
<head>
<title>Control</title>
</head>
<body>
<?php

if(!$_GET[id] && !$_GET[pw])
{
	echo("<form method=get action=index.php>user_id<br><input type=text name=id value='guest'><br><br>user_pw<br><input type=password name=pw value='guest'><br><br><input type=submit value='Login'></form>");
}

if($_GET[id] && $_GET[pw])
{
	if($_GET[id]=="guest" && $_GET[pw]=="guest")
	{
		$id=md5("guest");
		exit("<meta http-equiv=refresh content=0;url='index.php?login_ok=$id'>");
	}

	else echo("Wrong");
}

?>
<!-- guest -> admin -->
</body>
</html>
