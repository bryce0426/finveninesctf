<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_webpr0xyFLagchalleng2@");
if(eregi("[^0-9]",$_GET['view'])) $_GET[view]=1;
?>
<html>
<head>
<style type="text/css">
body { padding:20pt; border:5pt solid black; }
.menu {background:silver; font-size:15pt;text-align:center; border:2pt solid black;padding:5pt;}
.menu:hover { background:white; }
table { padding:10pt; }
</style>
<title>Contorl 2</title>
</head>
<body>
<a class=menu onclick=location.href='index.php'>Home</a>
<a class=menu onclick=location.href='?mode=write'>Write</a>
<br><br>
<?php
@mysql_connect("localhost","control2","control2");
@mysql_select_db("control2") or die("db error");

if(ini_get("magic_quotes_gpc")!=1) foreach($_POST as $no=>$val) $_POST[$no]=addslashes($val);

if($_GET['mode']=="write")
{
	if($_POST['sub'] && $_POST['memo'])
	{
		$tm=time();
		$_POST[sub]=htmlspecialchars($_POST[sub]);
		$_POST[memo]=htmlspecialchars($_POST[memo]);
		@mysql_query("insert into board(tm,id,sub,memo) values('$tm','guest','$_POST[sub]','$_POST[memo]')");
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	echo("<form method=post action=index.php?mode=write>");
	echo("<input type=text name=sub size=50><br><textarea name=memo cols=50 rows=10></textarea><br><input type=submit></form>");

	exit();
}

if(isset($_GET['view']))
{
	$q=@mysql_fetch_array(mysql_query("select * from board where tm='$_GET[view]'"));

	if($q && $_GET[mode]=="modify")
	{
		if($q[id]=="admin") $q[memo]="Password is $password";
                echo("<br><br><textarea rows=1 cols=50>$q[sub]</textarea><br><br><textarea cols=50 rows=10>$q[memo]</textarea><br><input type=submit><br><br>");exit();
	}

	 if($q)
        {
                if($q[id]=="admin") exit("Access Denied");
                echo("$q[sub]<br><br>$q[memo]<br><br><a class=menu onclick=location.href='?mode=modify&view=$_GET[view]'>Modify</a>");
		exit();
        }

}


$q=mysql_query("select * from board where id<>'admin'  order by tm desc limit 0,10");

echo("<table border=0 align=center width=100%>");

echo("<tr onclick=location.href='?view=1414549130' onmouseover=this.style.background='silver' onmouseout=this.style.background='white'><td width=100 align=center>".date('Y-m-d')."</td><td width=100 align=center>admin</td><td><b>READ ME</b></td></tr>");

while($d=mysql_fetch_array($q))
{
	echo("<tr onclick=location.href='?view=$d[tm]' onmouseover=this.style.background='silver' onmouseout=this.style.background='white'><td width=100 align=center>".date('Y-m-d')."</td><td width=100 align=center>$d[id]</td><td>$d[sub]</td></tr>");	
}

?>
</body>
</html>
