<?php @session_start(); ?>
<html>
<head>
<title>Control 3</title>
</head>
<body>
<?php
@mysql_connect("localhost","control3","control3");
@mysql_select_db("control3");

if($_SESSION[control3])
{
	if($_SESSION[control3]=="admin")
	{
		$password=md5("$_SERVER[REMOTE_ADDR]_tiger_c0ntrolllllll3333lllll1l");
		echo("Password is $password");
		exit();
	}
	if($_GET[mode]=="logout")
	{
		$_SESSION[control3]="";
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	if($_GET[mode]=="modify")
	{
		$q=@mysql_fetch_array(mysql_query("select * from mem where id='$_SESSION[control3]'"));
		if($_POST[id] && $_POST[pw] && $_POST[check])
		{
			if(sha1($_POST[id])!=$_POST[check]) exit("Access Denied");
			$_POST[id]=addslashes($_POST[id]);
			$_POST[pw]=md5($_POST[pw]);
			@mysql_query("update mem set pw='$_POST[pw]' where id='$_POST[id]' and id<>'guest'");
			exit("Done<meta http-equiv=refresh content=1;url=index.php>");
		}

		$check=sha1($q[id]);
		echo("<form method=post action=?mode=modify><input type=hidden name=check value='$check'>user_id<br><input type=text name=id value='$q[id]'><br><br>user_pw<br><br><input type=password name=pw 
value='guest'><br><br><input 
type=submit></form>");
	}

	if(!$_GET[mode]) echo("hi $_SESSION[control3]<hr><br><a href=?mode=modify>modify</a><br><br><a href=?mode=logout>logout</a>");
}


if(!$_SESSION[control3])
{
	if($_POST[id] && $_POST[pw])
	{
		$_POST[id]=addslashes($_POST[id]);
		$_POST[pw]=md5($_POST[pw]);
		$q=@mysql_fetch_array(mysql_query("select id from mem where id='$_POST[id]' and pw='$_POST[pw]'"));
		if($q[id])
		{
			$_SESSION[control3]="$q[id]";
			exit("<meta http-equiv=refresh content=0;url=index.php>");
		}
	}
	echo("<form method=post action=index.php>user_id<br><input type=text name=id value='guest'><br><br>user_pw<br><br><input type=password name=pw value='guest'><br><br><input type=submit></form>");
}
?>
</body>
</html>
