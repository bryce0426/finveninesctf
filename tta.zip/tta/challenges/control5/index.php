<?php @session_start(); ?>
<html>
<head>
<title>Control 5</title>
</head>
<body>
<center><h1>Control 5</h1>
<?php
$users_dir = md5(base64_encode("users"));

if(!$_SESSION[control5])
{
	if($_GET[id] && $_GET[pw])
	{
		$user = $_GET[id].":".$_GET[pw];
		$f=@file("$users_dir/$user");
		if(!$f) exit("not found");
		$_SESSION[control5] = "$_GET[id]";
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	echo("<form method=get action=index.php>user_id<br><input type=text name=id><br><br>user_pw<br><input type=password name=pw><br><br><input type=submit></form>");
}

if($_SESSION[control5])
{

	if($_GET[mode]=="logout")
	{
		$_SESSION[control5]="";
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	if($_GET[mode]=="admin" && $_SESSION[control5]=="admin")
	{
	        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_param2t2rc0ntr0L@");
		echo("Password is $password<hr>");
	}

	echo("hi $_SESSION[control5]");

	if($_SESSION[control5]=="admin" && $_SERVER[REMOTE_ADDR]!="127.0.0.1") exit("<meta http-equiv=refresh content=0;url=index.php?mode=logout>");

	echo("<br><br><a href=?mode=logout>[logout]</a><br><br><a href=?mode=admin>[admin page]</a><br>");

}

?>
<br><br><a href=index.phps>index.phps</a>
</center>
</body>
</html>
