<html>
<head>
<title>crack me</title>
</head>
<body>
<?php
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_basicauthcrAck");
	echo("Password is $password");
?>

</body>
</html>
