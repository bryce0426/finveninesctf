<html>
<head>
<style type="text/css">
* { width:100%; height:100%; }
</style>
<title>Flash 100</title>
</head>
<body><br><br>
<embed src=flash.swf width=100% height=100%></embed>
</body>
</html>
