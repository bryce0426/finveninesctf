tboard admin page<br><br>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_guess1adminpageguess@");
echo("Password is $password");
?>
