<!--
 __                                                                                               __                                        __              __               
/  |                                                                                             /  |                                      /  |            /  |              
$$ |____    ______   _____  ____    ______          ______   ______    ______    ______         _$$ |_     ______   _____  ____    ______  $$ |  ______   _$$ |_     ______  
$$      \  /      \ /     \/    \  /      \        /      \ /      \  /      \  /      \       / $$   |   /      \ /     \/    \  /      \ $$ | /      \ / $$   |   /      \ 
$$$$$$$  |/$$$$$$  |$$$$$$ $$$$  |/$$$$$$  |      /$$$$$$  |$$$$$$  |/$$$$$$  |/$$$$$$  |      $$$$$$/   /$$$$$$  |$$$$$$ $$$$  |/$$$$$$  |$$ | $$$$$$  |$$$$$$/   /$$$$$$  |
$$ |  $$ |$$ |  $$ |$$ | $$ | $$ |$$    $$ |      $$ |  $$ |/    $$ |$$ |  $$ |$$    $$ |        $$ | __ $$    $$ |$$ | $$ | $$ |$$ |  $$ |$$ | /    $$ |  $$ | __ $$    $$ |
$$ |  $$ |$$ \__$$ |$$ | $$ | $$ |$$$$$$$$/       $$ |__$$ /$$$$$$$ |$$ \__$$ |$$$$$$$$/         $$ |/  |$$$$$$$$/ $$ | $$ | $$ |$$ |__$$ |$$ |/$$$$$$$ |  $$ |/  |$$$$$$$$/ 
$$ |  $$ |$$    $$/ $$ | $$ | $$ |$$       |      $$    $$/$$    $$ |$$    $$ |$$       |        $$  $$/ $$       |$$ | $$ | $$ |$$    $$/ $$ |$$    $$ |  $$  $$/ $$       |
$$/   $$/  $$$$$$/  $$/  $$/  $$/  $$$$$$$/       $$$$$$$/  $$$$$$$/  $$$$$$$ | $$$$$$$/          $$$$/   $$$$$$$/ $$/  $$/  $$/ $$$$$$$/  $$/  $$$$$$$/    $$$$/   $$$$$$$/ 
                                                  $$ |               /  \__$$ |                                                  $$ |                                        
                                                  $$ |               $$    $$/                                                   $$ |                                        
                                                  $$/                 $$$$$$/                                                    $$/                                         
														ver 1.0
														contact : admin@hpt.com
-->
<html>
<head>
<script type="text/javascript" src="script.js"></script>
<style type="text/css">
.wrap { width:500pt; height:300pt; background:black;}
.top { width:500pt;height:50pt;background:silver;text-align:center; }
.main { width:500pt; height:200pt; background:gray; text-align:left; }
.bottom { width:500pt; height:50pt; background:white;text-align:center; }
</style>
<title>guess 2</title>
</head>
<body>
<center><br><br>
<!-- wrap -->
<div class=wrap>
	<!-- top menu -->
	<div class=top>
	TOP MENU
	</div>
	<!-- top menu -->

	<!-- main -->
	<div class=main>
	MAIN
	</div>
	<!-- main -->

	<!-- bottom -->
	<div class=bottom>
	COPYRIGHT
	</div>
</div>
<!-- wrap -->

</body>
</html>
