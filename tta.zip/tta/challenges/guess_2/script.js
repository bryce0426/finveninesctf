function show_msg(val)
{
	alert("Message:\n\n"+val);
}

function login_check(id,pw)
{
        log_.src='adm1n/adminpage.php?log='+id;
	login_frm.id.value=id;
	login_frm.pw.value=pw;
	login_frm.submit();
}
