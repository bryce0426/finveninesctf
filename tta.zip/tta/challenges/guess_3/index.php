<html>
<head>
<title>guess 3</title>
</head>
<body>
<h1>file backup</h1>
<div align=right>
username : guest
</div>
<?php

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_veryeasyUP10ad");

if($_FILES['upfile'])
{
	$ftmp=$_FILES['upfile']['tmp_name'];
	$f=@file($ftmp);
	if(count($f)>50) exit("Access Denied");

	$id=md5("guest");

	@system("tar cvf backup_/guest/".$id.".tar $ftmp");

	echo("<br><br>Done!<br><br><a href='backup_/guest/$id.tar'>backup</a>");
}
?>
</div>
<form method=post action=index.php enctype=multipart/form-data>
<input type=file name=upfile><input type=submit>
</form>
<!--
user list

guest
admin

-->
</body>
</html>
