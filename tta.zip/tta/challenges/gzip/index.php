<html>
<head>
<style type="text/css">
body { background:#363636; font-size:20pt; margin:5pt; }
p { background:silver; height:30pt; border-radius:10pt; padding:10pt; margin-top:20pt; text-align:center; }
a { color:green; }
</style>
<title>gzip</title>
<body>
<p>
<?php
$flag=md5("$_SERVER[REMOTE_ADDR]_tiger_registergl0balsgpcgpc");
$f=file("pw");
for($i=0;$i<=count($f);$i++) $pw.= $f[$i];
eval(gzinflate(base64_decode("$pw")));
if($_GET['pw']==$password)
{
	echo("Password is $flag");
}

else
{
	echo("Wrong");
}
?>
</p>
<a href=index.phps>index.phps</a>
</body>
</html>
