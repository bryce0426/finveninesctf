<html>
<head>
<style type="text/css">
body { margin:20pt; background:black; color:yellow; font-size:20pt;}
input { background:black; color:white; border:0; }
input[type=text] { border:1pt solid green; }
</style>
<title>hack me if you can</title>
</head>
<body>
<?php
mysql_connect("localhost","hackme","hackme");
mysql_select_db("hackme");

$ck=mysql_fetch_array(mysql_query("select count(name) from name"));
if($ck[0]>=10000) mysql_query("delete from name");

if($_POST[name])
{
	if(eregi("union|sleep|bench|if",$_POST[name])) exit("Access Denied");
	@mysql_query("insert into val(name,ip) values('$_POST[name]','$_SERVER[REMOTE_ADDR]')");
	echo("Done ".time());
}

?>
<form method=post action=index.php>
<input type=text name=name><input type=submit value='insert'>
</form>
<br>select pw from admin<br>
<a href=index.phps>index.phps</a>
</body>
</html>
