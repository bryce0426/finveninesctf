<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_jsjspacK2rrr@");
echo("Password is $password");
?>
