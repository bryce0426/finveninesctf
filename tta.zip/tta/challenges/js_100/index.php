<html>
<head>
<title>js 100</title>
</head>
<body>
<br><br><center><h1><u>JS100</u></h1></center>
<script>
    eval(function(p, a, c, k, e, d) {
        e = function(c) {
            return c
        };
        if (!''.replace(/^/, String)) {
            while (c--) {
                d[c] = k[c] || c
            }
            k = [

                function(e) {
                    return d[e]
                }
            ];
            e = function() {
                return '\\w+'
            };
            c = 1
        };
        while (c--) {
            if (k[c]) {
                p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c])
            }
        }
        return p
    }('4(0.5.3("0.6")!=-1)8.2="2.7";', 9, 9, 'document||href|indexOf|if|URL|cookie|php|location'.split('|'), 0, {}))
</script>
</body>
</html>
