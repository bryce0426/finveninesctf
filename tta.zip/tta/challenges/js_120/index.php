<html>
<head>
<title>JS 120</title>
<script type="text/javascript" src=".js"></script>
<style type="text/css">
body{background:black;color:lightgreen;margin:0;font-size:100pt;}
</style>
<body>
Wrong
</body>
</html>
