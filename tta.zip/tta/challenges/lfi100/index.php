<html>
<head>
<title>LFI 100</title>
</head>
<body>
<?php

	if($_GET[file])
	{
		$_GET[file]=stripslashes($_GET[file]);
		if(eregi("\.\.|:|/",$_GET[file])) exit("Access Denied");
		if(strlen($_GET[file])>7) exit("Access Denied");
		if($_GET[file]=="pw.php\0") @include "pw.php";
		@include "$_GET[file].txt";
		echo($password);
	}

	else
	{
		echo("<a href=?file=test>test.txt</a><br>");
		echo("<a href=?file=hi>hi.txt</a><br>");
		echo("pw.php");
	}

?>
</body>
</html>
