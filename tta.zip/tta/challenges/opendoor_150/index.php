<html>
<head>
<style type="text/css">
body { background:black; margin:0; color:lightgreen; }
a { font-family:'Webdings';font-size:100pt; font-weight:bold; color:green; }
.link { color:blue; font-family:'Dotum';font-size:15pt; border-bottom:1pt solid white; }
</style>
<title>opendoor 150</title>
</head>
<body>
<?php
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_welecomeMysq1");
	if($_GET[host] && $_GET[user] && $_GET[password] && $_GET[db])
	{
		mysql_connect("$_GET[host]","$_GET[user]","$_GET[password]") or die(mysql_error());
		mysql_select_db("$_GET[db]") or die("db error");
		echo($password);
	}		
?>
<form method=get action=index.php>
<a>h</a><br>host<br><input type=text name=host><br>
user<br><input type=text name=user><br>
password<br><input type=text name=password><br>
database<br><input type=text name=db><br>
<input type=submit><input type=button value='source' onclick=location.href='index.phps'>
</form>
</body>
</html>
