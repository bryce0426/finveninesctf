
<?php
	// password is engine_0ff!
	echo("READ ME");
?>
