<html>
<head>
<title>PHP 1</title>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_basicphp1authk2Y");

$user="admin";
$check=$$_GET[u];

if($_GET[user] && $_GET[user]==$check)
{
	echo("Password is $password");
}

?>
<br><a href=index.phps>index.phps</a>
</body>
</html>
