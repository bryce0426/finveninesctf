<html>
<head>
<title>read_me</title>
</head>
<body>
<a href=page/form.html>form</a><br>
<a href=page/table.html>table</a><br>
<a href=page/select.html>select</a><br>
</body>
</html>
