<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_1ndex!@!");

echo("Password is $password");

?>
