<h2>Contact</h2>
<textarea style=width:90%;height:90%>
name :
phone :
=============================



=============================
</textarea><br><br>
<center><input type=submit></center>

