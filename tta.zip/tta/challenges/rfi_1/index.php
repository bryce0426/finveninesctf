<html>
<head>
<style type="text/css">
body { background:silver; margin:0 }
.wrap { width:500pt; height:300pt; background:#F6F6F6; border:1pt solid black; }
.top_menu { width:500pt; background:gray; border-bottom:1pt solid black; text-align:left; }
.main {width:500pt; height:200pt; text-align:left; padding:10pt; }
input { width:20%; background:gray; border:0; }
input:hover { background:#3399FF; color:white; }
.bottom { font-size:9pt; color:blue; }
</style>
<title>RFI 1</title>
</head>
<body><center><br>
<?php
function sender($val)
{
	$host=strstr($val,"//");
	$host=substr($host,2);
	$page=strstr($host,"/");
	$host=str_replace($page,"",$host);

	if(eregi("$_SERVER[HTTP_HOST]",$host)) exit("access denied");

	$re="GET $page HTTP/1.0\r\n";
	$re.="Host: $host\r\n";
	$re.="\r\n";

	$so=@fsockopen("$host","80") or die("error");
	@fputs($so,$re);

	while(!feof($so)) $result.=fgets($so);

	$result=strstr($result,"\r\n\r\n");
	$result=str_replace("</xmp>","&lt;/xmp>",$result);
	fclose($so);
	return $result;
}
?>
<div class=wrap>
	<div class=top_menu>
	<input type=button value='Main' onclick=location.href='?page=main.php'>
        <input type=button value='About' onclick=location.href='?page=about.php'>
        <input type=button value='Board' onclick=location.href='?page=board.php'>
        <input type=button value='Contact' onclick=location.href='?page=contact.php'>
	</div>

	<div class=main>
	<?php
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_fakeRF1T.T");

	if(substr($_GET[page],0,1)=="/") exit("access denied");
        if(substr($_GET[page],0,1)==".") exit("access denied");

	if(eregi("ftp:|php:|data:",$_GET[page])) exit("access denied");

	if(eregi("//",$_GET[page]))
	{
		$get=sender($_GET[page]);
		if($get)
		{
			echo("<xmp>$get</xmp>");
			if(eregi("system|exec|passthru",$get)) echo("<h3>Password is $password</h3>");
		}
	}

	if($_GET[page]=="main.php") include "main.php";
        if($_GET[page]=="about.php") include "about.php";
        if($_GET[page]=="board.php") include "board.php";
        if($_GET[page]=="contact.php") include "contact.php";
		
	?>
	</div>

	<div class=bottom>RFI 1</div>


</div>
</body>
</html>
