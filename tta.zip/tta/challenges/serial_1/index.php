<html>
<head>
<title>Serial 1</title>
</head>
<body>
<?php

class Admin
{
	function login($id)
	{
		if($id=="admin")
		{
		        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_bas1CseRia11");
			echo("Password is $password");
			exit();
		}
	}	
}

class User
{
	function login($id,$pw)
	{
		if($id=="guest" && $pw=="guest")
		{
			$this->id = $id;
			$this->pw = $pw;
			setCookie("user",serialize($this));
			echo("hi $id");
			exit();
		}
	}

	public $id;
	public $pw;
}

if($_GET[id] && $_GET[pw])
{
	$info = new User();
	$info -> login($_GET[id],$_GET[pw]);
}

if($_COOKIE[user])
{
	$info = unserialize($_COOKIE[user]);
	$info -> login($info->id,$info->pw);
}

?>
<form method=get action=index.php>
<input name=id value=guest>
<input name=pw value=guest>
<input type=submit>
</form>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
