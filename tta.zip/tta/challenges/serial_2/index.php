<html>
<head>
<title>Serial 2</title>
</head>
<body>
<?php
@mysql_connect("localhost","sql_serial","sql_serial");
@mysql_select_db("sql_serial");

class check
{
	public $id;

	function __destruct()
	{
		$user="{$this->id}";
		$q=mysql_fetch_array(mysql_query("select id from mem where id='$user'"));
		if($q) echo("hi! $q[id]");
	}
}

if($_GET[login] && $_GET[data])
{
	$user_data = unserialize($_GET['data']);
}
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
