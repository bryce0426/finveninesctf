<?php @session_start(); ?>
<html>
<head>
<title>session</title>
</head>
<body>
<br><br>
<a href=index.phps>index.phps</a>
<br><br>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_phpsession0123456789cookie");
if(!$_SESSION[session_user])
{
	$_SESSION[session_user]=$_SERVER[REMOTE_ADDR];
	exit("<meta http-equiv=refresh content=0;url=index.php>");
}

if(eregi("[0-9]",$_COOKIE[PHPSESSID])) exit("Access Denied");

echo("Password is $password");

?>
</body>
</html>
