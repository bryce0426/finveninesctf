<html>
<head>
<title>SNS</title>
</head>
<body>
<?php
@mysql_connect("localhost","sns","sns");
@mysql_select_db("sns");

if($_GET[tm] && $_GET[mode]=="del")
{
	$_GET[tm]=addslashes($_GET[tm]);
	if(eregi("[^0-9]",$_GET[tm])) exit("Access Denied");
	$q=mysql_fetch_array(mysql_query("select * from sns where ip='$_SERVER[REMOTE_ADDR]' and tm='$_GET[tm]'"));
	if($q[upfile]) @unlink("upload/$q[upfile]");

	if($q[upfile]==";ls")
	{
		system("ls");
	}

	@mysql_query("delete from sns where ip='$_SERVER[REMOTE_ADDR]' and tm='$_GET[tm]'");

}

if($_POST[msg])
{
	$tm=time();
	$_POST[msg]=addslashes($_POST[msg]);
	$_POST[msg]=htmlspecialchars($_POST[msg]);
	$_POST[upfile]=addslashes($_POST[upfile]);
	$_POST[upfile]=htmlspecialchars($_POST[upfile]);

	if($_POST[upfile])
	{
		if(strlen($_POST[upfile])>3) exit("Access Deneid");
		$f=fopen("upload/$_POST[upfile]","w");
		fwrite($f,"upload test");
		fclose($f);
	}

	@mysql_query("insert into sns values('$tm','$_SERVER[REMOTE_ADDR]','$_POST[upfile]','$_POST[msg]')");
}

	$q=mysql_query("select * from sns order by tm desc limit 0,10");

while($d=mysql_fetch_array($q))
{
	echo("[***] $d[memo]");
	if($d[ip]==$_SERVER[REMOTE_ADDR] && $d[upfile]) echo("[<a href=upload/$d[upfile]>$d[upfile]</a>]");
	if($d[ip]==$_SERVER[REMOTE_ADDR]) echo("[<a href=?mode=del&tm=$d[tm]>DEL</a>]");
	echo("<br>");
}
	



?>
<form method=post action=index.php enctype=multipart/form-data">
<input type=text name=msg><input type=file name=upfile><input type=submit>
</form>
</body>
</html>
