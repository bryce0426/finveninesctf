<html>
<head>
<style type="text/css">
* { margin:0 auto; padding:10pt; }
input[type=submit] { width:100pt; }
div { background:lightblue;text-align:center;width:300pt; }
</style>
<title>SQL 150</title>
</head>
<body>
<center>
<?php
	mysql_connect("localhost","sql150","sql150");
	mysql_select_db("sql150");
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_sql150clear!");

	if($_GET[no])
	{
		if(eregi("[a-z]",$_GET[no])) exit("Access Denied");
		$query="select * from user where no=$_GET[no]";
		$data=mysql_fetch_array(mysql_query($query));
		if($data[user]=="guest") echo("hi guest");
		else if($data[user]=="admin") echo("password is $password");
		else echo("Wrong<br>".htmlspecialchars($query));
	}
?>
</center>

<form method=get action=index.php>
<div>No <input type=text name=no value='1234'><input type=submit></div>
</form>
<center><a href=index.phps>index.phps</a></center>
</body>
</html>