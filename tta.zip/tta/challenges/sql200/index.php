<html>
<head>
<style type="text/css">
#no { width:20pt;background:orange;float:left;text-align:center; }
#memo { width:300pt;height:30pt;background:silver;}
</style>
<title>SQL 200</title>
</head>
<body>
<?php
	mysql_connect("localhost","sql200","sql200");
	mysql_select_db("sql200");
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_un1onselecT");
	if(!$_GET[no]) $_GET[no]=1;

	if($_GET[flag])
	{
		$_GET[flag]=addslashes($_GET[flag]);
		$q=mysql_fetch_array(mysql_query("select flag from flag where flag='$_GET[flag]'"));
		if($q[flag]==$_GET[flag])
		{
			echo("<div id=no>!</div><div id=memo><b>password is $password</b></div>");
		}

	}

	$q=mysql_query("select * from board where no='$_GET[no]'");
	$d=mysql_fetch_array($q);

	echo("<div id=no>$d[no]</div><div id=memo>$d[memo]</div>");
	echo("<form method=get action=index.php><div id=no>0</div><div id=memo>FLAG : <input type=text name=flag><input type=submit></form>");


?>
<center><a href=index.phps>index.phps</a></center>
</body>
</html>
