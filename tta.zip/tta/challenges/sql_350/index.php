<html>
<head>
<style type="text/css">
body { background:#696969; padding:10pt; margin:0 auto;}
h1 { text-align:center; border-bottom:10pt solid gray; padding-bottom:20pt; color:silver; }
input {background:#363636; color:white; }
</style>
<title>SQL 350</title>
</head>
<body>
<h1>SQL 350</h1>
<form method=get action=index.php>
user_id<br><input name=id value='guest'><br><br>
user_pw<br><input name=pw value='guest'><br><br>
<input type=submit>
</form>
<?php
@mysql_connect("localhost","sql_350","sql_350");
@mysql_select_db("sql_350");

if(isset($_GET['id']) && isset($_GET['pw']))
{
	$_GET['id']=addslashes($_GET['id']);
	$_GET['pw']=addslashes($_GET['pw']);

	$_GET[id]=mb_convert_encoding($_GET[id],'utf-8','euc-kr');

	foreach($_GET as $ck)
	{
		if(eregi("from|pw|\)|\)| |%|=|>|<|@",$ck)) exit("Access Denied");
	}

	if(eregi("union",$_GET['id'])) exit("Access Denied");
 
	$data=@mysql_fetch_array(mysql_query("select lv from members where id='$_GET[id]' and pw=md5('$_GET[pw]')"));

	if($data)
	{
		if($data[0]=="1") echo("level : 1<br><br>");
		if($data[0]=="2") echo("level : 2<br><br>");
	} 

	if($data[0]=="3")
	{
		$password=1234;
		echo("Password is $password");
	}

	if(!$data)
	{
		echo("Wrong");
	}
}
 
?>
</body>
</html>
 
