<html>
<head>
<title>SQL agent</title>
</head>
<body>
<?php
@mysql_connect("localhost","sql_agent","sql_agent");
@mysql_select_db("sql_agent");

foreach($_GET as $no=>$val) { $_GET[$no]=addslashes($val); }
foreach($_POST as $no=>$val) { $_POST[$no]=addslashes($val); }
foreach($_COOKIE as $no=>$val) { $_COOKIE[$no]=addslashes($val); }

$ip=md5($_SERVER['REMOTE_ADDR']);
$agent=getenv("http_user_agent");

$q=@mysql_fetch_array(mysql_query("select * from log where ip='$ip'"));

if(!$q) @mysql_query("insert into log(agent,ip) values('$agent','$ip')");
if($q)
{
	@mysql_query("update log set agent='$agent' where ip='$ip'");
	echo("ip : $q[ip]<br><br>agent : $q[agent]");
}

?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
