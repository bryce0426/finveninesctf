<html>
<head>
<title>SQL Binary</title>
</head>
<body>
<?php
@mysql_connect("localhost","sql_binary","sql_binary");
@mysql_select_db("sql_binary");

/*

mysql> desc mem;
+-------+-------------+------+-----+---------+-------+
| Field | Type        | Null | Key | Default | Extra |
+-------+-------------+------+-----+---------+-------+
| no    | int(50)     | YES  |     | NULL    |       |
| id    | varchar(50) | YES  |     | NULL    |       |
| pw    | varchar(50) | YES  |     | NULL    |       |
+-------+-------------+------+-----+---------+-------+
3 rows in set (0.00 sec)

*/

if($_GET[no])
{
	if(eregi("from|union|ascii|char|0x",$_GET[no])) exit("Access Denied");
	$q=@mysql_fetch_array(mysql_query("select * from mem where no=$_GET[no]"));
	if($q)
	{
		echo("no : $q[no]<br>id : $q[id]<br>pw : ?");
		exit();
	}
}

echo("<form method=get action=index.php>user_no<br><input type=text name=no value=1><br><br><input type=submit></form>");
?>
<br>
<a href=index.phps>index.phps</a>
</body>
</html>
