<?php header("Content-Type: text/html; charset=euc-kr");?>
<html> 
<head>
<meta http-equiv=Content-Type content="text/html; charset=euc-kr">
<style type="text/css"> 
* { margin:0 auto; padding:10pt; } 
div { background:lightgreen;text-align:center;width:350pt; } 
</style> 
<title>SQL BLIND 2</title> 
</head> 
<body> 
<center> 
<?php 
	mysql_connect("localhost","sql_blind2","sql_blind2");
	mysql_select_db("sql_blind2");

	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_pwis1234");

	if($_GET[jumin])
	{
		if($_GET[jumin]=="@@admin@@") echo("password is <b>$password</b><br>");
		if($_GET[jumin]=="pwis1234") echo ("password is <b>$password</b><br>");

		$_GET[jumin]=addslashes($_GET[jumin]);
		$_GET[pw]=addslashes($_GET[pw]);

		if(eregi("#|select|/",$_GET[jumin])) exit("<div>Access Denied</div>");

		$q=mysql_fetch_array(mysql_query("select jumin,pw from mem where jumin=$_GET[jumin] and pw='$_GET[pw]'"));

		if($q[pw]) echo("True");
		else echo("False");
	}
	
?>
<form method=get action=index.php>
<div>
	<input type=text name=jumin value=1234><input type=password name=pw value='higuest'><input type=submit>
</div>
</form>
<br><a href=index.phps>index.phps</a>
</body>
</html>
