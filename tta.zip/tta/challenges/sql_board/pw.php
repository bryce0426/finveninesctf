<?php
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_sql1nJeCTionseARcH@");
	echo("Password is $password");
?>
