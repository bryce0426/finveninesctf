<html>
<head>
<style type="text/css">

</style>
<title>SQL Columns</title>
</head>
<body>
<p>information</p>
<?php
mysql_connect("localhost","sql_columns","sql_columns");
mysql_select_db("sql_columns");
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_AsASasaS");
$columns=$_GET[columns];

if(eregi("union|#|-|from|select",$columns)) exit("Access Denied");

$q=mysql_fetch_array(mysql_query("select $columns from mem"));

if($q)
{
	print_r($q);
}


if($q[id]=="admin")
{
	echo("<br><b>Password is $password</b>");
}


?>
<br>
<a href=?columns=id>id</a><br>
<a href=?columns=phone>phone</a><br>
<a href=?columns=name>name</a><br>
<a href=index.phps>index.phps</a><br>
</body>
</html>
