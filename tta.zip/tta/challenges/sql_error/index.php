<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Admin page</title>
</head>
<body>
<?php
	mysql_connect("localhost","sql_error","sql_error") or die("* mysql_connect error");
	mysql_select_db("sql_error");
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_err0rbased");
?>
<div id="main">
	<h1>Admin page</h1>
	<h2>Login</h2>
		<div class="text">
		<?php
			if($_GET[pw])
			{
				if(eregi("<|>|=|union|where|\||&|\!|if|sleep|bench|like",$_GET[pw])) exit("Access Denied");
				$q=mysql_fetch_array(mysql_query("select pw from admin where pw='$_GET[pw]'"));
				if(mysql_error()) echo(mysql_error());


				if($q[pw] && $q[pw]==$_GET[pw])
				{
					echo("Password is $password<br>");
				}

			}
		?>
		<form method=get action=index.php>
		Password : <input type=text name=pw><input type=submit>
		</div>
	</div>
<a href=index.phps>index.phps</a>
</body>
</html>
