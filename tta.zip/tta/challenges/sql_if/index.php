<html>
<head>
<style type="text/css">
body { background:#F6F6F6; color:#353535; padding:10pt; margin:0 auto; text-align:center;}
p { font-size:20pt;padding-top:20pt;}
a { color: green;font-size:25pt; }
</style>
<title>SQL if</title>
</head>
<body>
<?php

@mysql_connect("localhost","sql_if","sql_if");
@mysql_select_db("sql_if");

if(isset($_GET['pw']))
{
	sleep(1);

	if($_GET['pw']=="aatigerbb")
	{
		$password=md5("$_SERVER[REMOTE_ADDR]_tiger_tigeraabbccdd22eeFfgG@@");
		echo("Password is $password");
		exit();
	}
}

if(isset($_GET['no']))
{
	if(@eregi("%",$_SERVER['REQUEST_URI'])) exit("Access Denied");
	if(@eregi("from|union|select|and|or|not|&|\||benchmark|=|>|<|!|char|ascii| |\t|/|limit|\+|substring|mid|left|hex|-|pro|concat|bin|conv|elt|set|field|find|insert|load|locate|make|oct|ord",$_GET['no'])) exit("Access 
Denied");

	$q=@mysql_fetch_array(mysql_query("select * from list where no=($_GET[no])"));

	if($q['no']==3) exit("<b>Secret</b><br><br>hint : length = 9<br>column : id,no");

	echo("<p>$q[id]</p><br><br>");
}

if(!isset($_GET['no']))
{
	$q=mysql_query("select * from list");
	while($d=mysql_fetch_array($q))
	{
		echo("<a href=?no=$d[no]>$d[no]</a>&nbsp;");
	}
}
?>
<form method=get action=index.php>
Password : <input type=text size=10 maxlength=11 name=pw><input type=submit>
</form>
</body>
</html>

