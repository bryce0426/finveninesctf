<html>
<head>
<style type="text/css">
* { margin:0 auto; padding:10pt; }
input[type=submit] { width:150pt; }
</style>
<title>SQL insert</title>
</head>
<body>
<?php
	mysql_connect("localhost","sql_insert","sql_insert") or die("* mysql_connect error");
	mysql_select_db("sql_insert");

	if($_GET[cmd] && $_GET[id] && $_GET[pw])
	{
		$_GET[id]=addslashes($_GET[id]);

		if($_GET[cmd]=="join")
		{
			$ck=mysql_fetch_array(mysql_query("select count(id) from mem"));
			if($ck[0]>=1000) mysql_query("delete from mem");
			$q=mysql_fetch_array(mysql_query("select id from mem where id='$_GET[id]'"));
			if(!$q)
			{
				@mysql_query("insert into mem(id,pw,ip) values('$_GET[id]','$_GET[pw]','$_SERVER[REMOTE_ADDR]')") or die("Error");
				echo("Done");
				exit();
			}
		}

		if($_GET[cmd]=="login")
		{
			$q=@mysql_fetch_array(mysql_query("select * from mem where id='$_GET[id]'"));
			if($q[id] && $q[pw]==$_GET[pw])
			{
				echo("hi! ".htmlspecialchars($q[id])."<br>ip : ".htmlspecialchars($q[ip]));
				exit();
			}
		}

	}

?>

<form method=get action=index.php>
<table border=0 algin=center cellpadding=10>
<tr><td>username</td><td><input type=text name=id></td></tr>
<tr><td>password</td><td><input type=password name=pw></td></tr>
<tr><td><input type=submit name=cmd value='login'></td><td><input type=submit name=cmd value='join'></td></tr>
</table>
</form>


<center><a href=index.phps>index.phps</a></center>
</body>
</html>
