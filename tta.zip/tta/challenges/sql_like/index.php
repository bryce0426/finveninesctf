<html>
<head>
<style type="text/css">
body { background:black; color:silver; }
</style>
<title>SQL Like</title>
</head>
<body>
<b>HEX Filter</b><br><br>
<?php

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_h2xfilt2R");

mysql_connect("localhost","sql_hex","sql_hex") or die("mysql error");
mysql_select_db("sql_hex");

if($_GET[id] && $_GET[pw])
{
	$_GET[id]=addslashes($_GET[id]);
	$_GET[pw]=addslashes($_GET[pw]);

	if(eregi("#|=|>|<|0x",$_GET[pw])) exit("Access Denied");	

	$q=mysql_fetch_array(mysql_query("select id from mem where id='$_GET[id]' and pw=$_GET[pw]"));

	if($q[id])
	{
		echo("hi! $q[id]<br>");
		if($q[id]=="admin") echo("<b>Password is $password</b><br>");
		exit();
	}

	else
	{
		echo("Wrong");
		exit();
	}
}
?>
<form method=get action=index.php>
<table border=1 cellpadding=10>
<tr><td>id</td><td><input type=text name=id value='guest'></td></tr>
<tr><td>pw</td><td><input type=text name=pw value='1234'></td></tr>
<tr><td colspan=2 align=center><input type=submit></td></tr>
</table>
</form>
<a href=index.phps>index.phps</a>
</body>
</html>
