<html>
<head>
<style type="text/css">
body { background:black; color:white }
input[type=submit] { background:gray; width:100%; border:0; }
input[type=submit]:hover { color:white; }
table { padding-top:150px; }
</style>
<title>SQL Magic</title>
</head>
<body>
<?php
mysql_connect("localhost","sql_magic","sql_magic") or die("mysql error");
mysql_select_db("sql_magic");

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_substr1njection");

if($_GET[id] && $_GET[pw])
{
	$_GET[id]=addslashes($_GET[id]);
	$_GET[pw]=addslashes($_GET[pw]);

	if(strlen($_GET[id])>10) $_GET[id]=substr($_GET[id],0,10);
        if(strlen($_GET[pw])>10) $_GET[pw]=substr($_GET[pw],0,10);

	$q=mysql_fetch_array(mysql_query("select id from mem where id='$_GET[id]' and pw=md5('$_GET[pw]')"));

	if($q[id])
	{
		echo("hi $q[id]<br>");
		if($q[id]=="admin")
		{
			echo("<b>Password is $password</b>");
		}
		exit();
	}
}

?>
<form method=get action=index.php>
<table border=0 cellpadding=10 align=center>
<tr><td>username</td><td><input type=text name=id></td></tr>
<tr><td>password</td><td><input type=password name=pw></td></tr>
<tr><td colspan=2 align=center><input type=submit 
value='Login'></td></tr>
<tr><td colspan=2><a href=index.phps>index.phps</a></td></tr>
</table>
</body>
</html>
