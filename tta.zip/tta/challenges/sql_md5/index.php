<html>
<head>
<title>SQL MD5</title>
</head>
<body>
<form method=get action=index.php>
id : <input type=text name=id value='admin'>
pw : <input type=text name=pw>
<input type=submit>
<?php
	mysql_connect("localhost","sql_md5","sql_md5");
	mysql_select_db("sql_md5");
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_md5raw123");

	if($_GET[id] && $_GET[pw])
	{
		$_GET[id]=addslashes($_GET[id]);
		$_GET[pw]=md5($_GET[pw],true);

		$q=mysql_fetch_array(mysql_query("select id from user where id='$_GET[id]' and pw='$_GET[pw]'"));

		if($q[id])
		{
			echo("<hr>Password is $password");
		}

		else
		{
			echo("<hr>Wrong");
		}

	}
?>
<br>
<a href=index.phps>index.phps</a>
</body>
</html>
