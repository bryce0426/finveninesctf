<html>
<head>
<style type="text/css">
* { margin:0 auto; padding:10pt; }
input[type=submit] { width:100pt; }
div { background:lightblue;text-align:center;width:300pt; }
</style>
<title>SQL SPACE</title>
</head>
<body>
<center>
<?php
	mysql_connect("localhost","sql_space","sql_space");
	mysql_select_db("sql_space");

	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_spac3_BaR_FilteR");

	if($_GET[id] && $_GET[pw])
	{
		$_GET[pw]=addslashes($_GET[pw]);
		$_GET[id]=str_replace(" ","",$_GET[id]);
		$_GET[pw]=str_replace(" ","",$_GET[pw]);
		$query="select * from user where pw='$_GET[pw]' and user='$_GET[id]'";
		echo("<b>".htmlspecialchars($query)."</b><br>");
		$data=mysql_fetch_array(mysql_query($query));
		if($data[user]=="guest") echo("hi guest");
		if($data[user]=="admin") echo("password is $password");
	}
?>
</center>
<form method=get action=index.php>
<table border=0 align=center cellpadding=10>
<tr><td>ID</td><td><input type=text name=id value='guest'></td></tr>
<tr><td>PW</td><td><input type=password name=pw value='guest'></td></tr>
<tr><td colspan=2 align=center><input type=submit value='Login'></td></tr>
</table>
</form>
<center><a href=index.phps>index.phps</a></center>
</body>
</html>
