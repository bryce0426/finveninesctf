<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>SQL TABLE</title>
</head>
<body>
<div id="main">
<h1>SQL injection</h1>
<h2>read me</h2>
<div class="text">
</div>
<?php
        mysql_connect("localhost","sql_table","sql_table");
        mysql_select_db("sql_table");

        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_procedure2");

if(!$_GET[pw])
{
echo("
<form method=get action=index.php>
Password : <input type=text name=pw size=50><input type=submit>
");
}

if($_GET[pw])
{
	if(eregi("union|from",$_GET[pw])) exit("Access Denied");
	$q=mysql_fetch_array(mysql_query("select * from hidden_admin_tablee where hidden_password='$_GET[pw]'"));
	if($q)
	{
		if($q[0]=="36912" && $_GET[pw]=="36912") echo("Password is $password"); else echo("Wrong password!<br>");
		if($q[0]!="36912") echo("hi $q[0]");
	}

	else echo("Wrong");
}

?>
</form>
</div>
</body>
</html>
