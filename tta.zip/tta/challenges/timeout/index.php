<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>Admin page</title>
</head>
<body>
<?php
	mysql_connect("localhost","timeout","timeout") or die("* mysql_connect error");
	mysql_select_db("timeout");
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_timebaseddd");
?>
<center>
	<div id="all">
		<div id="main">
		<h1>Contact</h1>
<?php

	if($_POST[name] && $_POST[phone] && $_POST[contact])
	{
		$_POST[name]=addslashes($_POST[name]);
		$_POST[phone]=addslashes($_POST[phone]);
		$_POST[contact]=addslashes($_POST[contact]);

		@mysql_query("insert into contact(name,phone,contact) values('$_POST[name]',$_POST[phone],'$_POST[contact]')");
		@mysql_query("delete from contact");
		echo("<br><h2>Done<br><br><a href=index.php>Back</a></h2>");
		exit();
	}

	if($_POST[admin_pw])
	{
		$q=mysql_fetch_array(mysql_query("select pw from admin_table"));

		if($q[pw]!=$_POST[admin_pw]) echo("<h2>Wrong password<br><br><a href=index.php>Back</a></h2>");
		if($q[pw]==$_POST[admin_pw]) echo("<h2>Password is $password</h2>");
		exit();
	}


?>
		<h2>contact<br><form method=post action=index.php>
		<table border=0>
		<tr><td>name</td><td><input type=text name=name></td></tr>
		<tr><td>phone</td><td><input type=text name=phone></td></tr>
		<tr><td colspan=2><textarea style=width:100% name=contact></textarea></td></tr>
		<tr><td colspan=2 align=center><input type=submit></td></tr>
		</table>
		</h2>

		<h2>Login
		<input type=text name=admin_pw><input type=submit>
		</h2>

		</div>


	</div>
</center>
<a href=index.phps>index.phps</a>
</body>
</html>

