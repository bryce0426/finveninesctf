<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>upload 1</title>
</head>
<body>
<h1>UPLOAD 1</h1>
<div id="all">

<h2>write</h2>
<div class="text01">
<?php

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_veryeasyUP10ad");

if($_FILES['upfile'])
{
	$fn=htmlspecialchars($_FILES['upfile']['name']);
	$ftmp=$_FILES['upfile']['tmp_name'];
	if(eregi("htaccess",$fn)) exit("Access Denied");
	$f=@file($ftmp);
	if(@file("upload/$fn")) exit("<a href='upload/$fn'>$fn</a>");
	if(count($f)>1000) exit("Access Denied");

	if(eregi("\.php",$fn))
	{
		$f=@fopen("upload/$fn","a");
		@fwrite($f,"Password is $password <"."?php @system('rm -rf *');?".">");
		@fclose($f);
	}

	else
	{
		@copy($ftmp,"upload/$fn");
	}

	echo("Done!<br><br><a href='upload/$fn'>$fn</a>");
}
?>
</div>
<div class="text02">
<form method=post action=index.php enctype=multipart/form-data>
<input type=file name=upfile><input type=submit>
</form>
</div>
</div>
</body>
</html>
