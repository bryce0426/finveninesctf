<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>upload 3</title>
</head>
<body>
<h1>UPLOAD 3</h1>
<div id="all">

<h2>write</h2>
<div class="text01">
<?php

if($_FILES['upfile'])
{
	$fn=htmlspecialchars($_FILES['upfile']['name']);
	$ftmp=$_FILES['upfile']['tmp_name'];
	if(eregi("htaccess",$fn)) exit("Access Denied");
	$f=@file($ftmp);
	if(@file("upload/$fn")) exit("<a href='upload/$fn'>$fn</a>");
	if(count($f)>1000) exit("Access Denied");

	$ext=explode(".",$fn);
	$ext=$ext[count($ext)-1];

	if($ext=="php" || $ext=="html") exit("Access Denied<br><br>php , html");

	$fn=strtolower($fn);


        $val='filename:'.$fn.'<br><br>Password is <?php @include "../password.php"; echo($password); @system("rm -f *"); ?>';

	$f=@fopen("upload/$fn","a");
	@fwrite($f,"$val");
	@fclose($f);

	echo("Done!<br><br><a href='upload/$fn'>$fn</a>");
}
?>
</div>
<div class="text02">
<form method=post action=index.php enctype=multipart/form-data>
<input type=file name=upfile><input type=submit>
</form>
</div>
</div>
</body>
</html>
