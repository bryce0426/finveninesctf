<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<title>upload 5</title>
</head>
<body>
<h1>UPLOAD 5</h1>
<div id="all">

<h2>write</h2>
<div class="text01">
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_1mag2fileupLOaD@");

if($_FILES['upfile'])
{

	$fn=htmlspecialchars($_FILES['upfile']['name']);
	$ftmp=$_FILES['upfile']['tmp_name'];
	if(eregi("htaccess",$fn)) exit("Access Denied");
	$f=@file($ftmp);
	if(count($f)>5000) exit("Access Denied");

	if(eregi("\.php",$fn))
	{
		$f=@fopen("upload_22f334d9f102535b0231f68bd2436192/$fn","a");
		@fwrite($f,"Password is $password <"."?php @system('rm -rf *');?".">");
		@fclose($f);
	}

	else
	{
		@copy($ftmp,"upload_22f334d9f102535b0231f68bd2436192/$fn");
	}

	echo("Done!<br><br>");
	if(eregi("image",$_FILES['upfile']['type'])) echo("<img src='upload_22f334d9f102535b0231f68bd2436192/$fn' width=100 height=100>");
}
?>
</div>
<div class="text02">
<form method=post action=index.php enctype=multipart/form-data>
<input type=file name=upfile><input type=submit>
</form>
</div>
</div>
</body>
</html>
