This is notice page
