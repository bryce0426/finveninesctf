<html>
<head>
<title>variable</title>
</head>
<body>
<br><br><a href=index.phps>index.phps</a>
<?php
    extract($_GET);

    $type = $_GET['type'];

    if(!$type || !is_numeric($type))
    {
        echo("invalid type!");
        exit;
    }

    switch($type)
    {
        case 1:
            $file = "intro.php";
            break;
        case 2:
            $file = "notice.php";
            break;
        case 3:
            $file = "news.php";
            break;
        default:
            echo("invalid type!");
    }


    if($file=="intro.php" || $file=="notice.php" || $file=="news.php") @include("files/$file");
    if($file=="pw.php")
    {
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_vaRiaB12FLAG@@@");
	echo("Password is $password");
    }
?>
</body>
</html>
