<?php
if($_GET[script]==1)
{
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_XSSchalLenG233@");
	echo("Password is $password");
}

?>
