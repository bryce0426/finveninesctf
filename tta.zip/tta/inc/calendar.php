<script src="js/jquery.tools.min.js"></script>

<?php 
 $year = date('Y');
 $month = date('m');
 list($tday, $dday) = split('[ ]', 
         date('t w',mktime(0,0,1,$month,1,$year))); 
 ?> 
<p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_calendar.png" width="500" height="60" border="0"></p>
<center><h1><font color=white><?=$month?></font></h1><br>
 <table width=90% height=300 border=1 cellspacing=0 cellpadding=10 style=color:black; background="images/common/dotbg.png" align=center> 
 <tr align=center> 
 <td>��</td>
 <td>��</td>
 <td>ȭ</td>
 <td>��</td>
 <td>��</td>
 <td>��</td>
 <td>��</td>
 </tr>
 <tr align=center> 

 <?php 
 $col = 0; 
 $vtd = "<td>&nbsp;\n"; 

 for($i = 0; $i < $dday; $i++){ 	
	echo $vtd;
    $col++; 
 } 

 for($i = 1; $i <= $tday; $i++){ 

$q=mysql_fetch_array(mysql_query("select * from tbl_calendar where m='$month' and d='$i'"));

//if($q[val])echo("<td background='images/common/dotbg2.png' onclick=calendar_show('$q[val]');>$i</td>");

if($q[val])
{
echo("<td background='images/common/dotbg2.png'><div class='calendarInput' rel='#$i'>$i</div><div class='modal' id='$i'><b>$month/$i</b><br><br>$q[val]<p align=center><button class='close'> Close 
</button></p></div>");
}
else echo "<td>$i\n</td>"; 
      $col++; 

      if(($col == 7) && ($col !== $tday)){ 
           echo "<tr align=center>\n"; 
           $col = 0; 
      } 
 } 

 while($col > 0 && $col < 7){ 
      echo $vtd; 
      $col++; 
 } 
 ?> 
 </table>
<script>calendar();</script>
