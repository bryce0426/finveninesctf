<?php
mysql_connect("localhost","root","t1ger") or die("connection error");
mysql_select_db("wargame");

//mysql_query("SET NAMES utf-8");

if(ini_get("magic_quotes_gpc")!=1)
{
	foreach($_GET as $no=>$val) $_GET[$no]=addslashes($val);
        foreach($_POST as $no=>$val) $_POST[$no]=addslashes($val);
        foreach($_COOKIE as $no=>$val) $_COOKIE[$no]=addslashes($val);
}

function html_($val)
{
	$val=str_replace("<","&lt;",$val);
	$val=str_replace(">","&gt;",$val);
	$val=str_replace("'","&quot;",$val);
	return $val;
}


function get_rank($val)
{
	$q=mysql_query("select reg_id from tbl_user_probs order by reg_score desc,reg_auth asc limit 0,100");
	$i=1;
	while($d=mysql_fetch_array($q))
	{
		if($d[reg_id]==$val) return $i;
		$i++;
	}
}

function token_check($val)
{
	for($i=time()-60;$i<=time();$i++)
	{
		if(md5($i."00t1g2r_token00")==$val) $result=1;
	}

if($result!=1) exit("Token error");
}

function token_make()
{
	$val=md5(time()."00t1g2r_token00");
	return $val;
}

function getprobs($val)
{
	$val=sql_guard($val);
	$q=@mysql_fetch_array(mysql_query("select * from tbl_user_probs where reg_id='$val'"));
	if($q[reg_id]) return $q;
	else {$_SESSION[id]=""; exit("<meta http-equiv=refresh content=0;url='index.php?page=login'>"); }
}


function msg_check($val)
{
	$val=sql_guard($val);
	$q=@mysql_fetch_array(mysql_query("select count(1) from tbl_user_msg where reg_check=0 and reg_id='$val'"));
	return $q[0];
}

function getinfo($val)
{
	$val=sql_guard($val);
	$q=@mysql_fetch_array(mysql_query("select * from tbl_user where reg_id='$val'"));
	if($q[reg_id]) return $q;
        else
	{
		$_SESSION[id]="";
		$page = $_GET[page];
		if(eregi("[^a-z]",$page)) $page="";
		exit("<meta http-equiv=refresh content=0;url='index.php?page=login&return=$page'>");
	}
}

function sql_guard($val)
{
	if(ini_get("magic_quotes_gpc")!=1)
	{
		//$val=addslashes($val);
	}
	return $val;
}

function user_check($val)
{
	$val=sql_guard($val);
	$query=@mysql_fetch_array(mysql_query("select reg_id from tbl_user where reg_id='$val'"));
	if(!$query) exit("<p id=error>�������� �ʴ� ���̵� �Դϴ�.</p>");
}

function challenge($q)
{
	global $i;
	$probs=getprobs($_SESSION[id]);
	if($_GET[user])
	{
		$_GET[user]=sql_guard($_GET[user]);
		user_check($_GET[user]);
		$probs=getprobs($_GET[user]);
	}
	while($d=mysql_fetch_array($q))
	{
		$break="";
		for($j=0;$j<=2;$j++)
		{
		$k=$j+1;
		$qq=mysql_fetch_array(mysql_query("select reg_id,reg_prob".$d[reg_no]." from tbl_user_probs where reg_prob".$d[reg_no]."<>0 order by reg_prob".$d[reg_no]." asc limit $j,1"));
		if($qq[reg_id]) $break.="&nbsp;<img src='images/$k.bmp' width=20 height=20 border=0 title=".date('[Y-m-d]H:i:s',$qq[1])."> $qq[0]<br>";
		}
		if($break) $break="<br><h3>&nbsp;Breakthrough</h3><b>$break</b>";
		if($probs["reg_prob".$d[reg_no]])
		{ // clear
			$ctime=date('Y-m-d H:i:s',$probs["reg_prob".$d[reg_no]]);
			$result.="<button class='modalInput_clear' rel='#$i'>$d[reg_name]<br>Point:$d[reg_score]</button>
			<div class='modal' id='$i'><h2>$d[reg_name]</h2>
			<p><b><br>Type : $d[reg_type]<br>Point : $d[reg_score]<br><form method=post action='index.php?page=challenges'><font color=blue>Flag : <input type=text name=c_flag id=flag></font><input type=submit 
value='Auth'><br>Clear : $ctime</form></b>$break<br>$d[reg_discription]<br><br>URL : <a style=color:blue href='$d[reg_page]' target=blank>$d[reg_page]</a><br><br></p>
			<p align=center><button class='close'> Close </button></p>
			</div>";
		}
		else
		{
			$result.="<button class='modalInput' rel='#$i'>$d[reg_name]<br>Point:$d[reg_score]</button>
			<div class='modal' id='$i'><h2>$d[reg_name]</h2>
			<p><b>Type : $d[reg_type]<br>Point : $d[reg_score]<br><form method=post action='index.php?page=challenges'><font color=blue>Flag : <input type=text name=c_flag id=flag></font><input type=submit 
value='Auth'></form></b>$break<br>$d[reg_discription]<br><br>URL : <a style=color:blue href='$d[reg_page]' target=blank>$d[reg_page]</a><br><br></p>
			<p align=center><button class='close'> Close </button></p>
			</div>";
		}

		$i++;
	}
	return $result;
}

?>
