<?php header("Content-Type: text/html;charset=euc-kr");

if(!isset($_GET[id]) || $_GET[id]=="") echo('<p align="center"><img src="images/common/Title_forum.png" width="500" height="60" border="0"></p>');
if(isset($_GET[id]))
{
if($_GET[id]=="") $_GET[id]=null;
else {user_check($_GET[id]);
echo("<p align=center><br><font color=white size=5><b>Study board</b><br>".htmlspecialchars($_GET[id])."</font></p>");}
}
?>
              </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="990" valign="top" height="500">

<?php
if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();
getinfo($_SESSION[id]);

if(isset($_GET[id]) && $_GET[id]!=$_SESSION[id]) $_GET[id]=$_SESSION[id];

if($_GET[no])
{
	if(eregi("[^0-9]",$_GET[no])) $_GET[no]=1;

	$q=@mysql_fetch_array(mysql_query("select * from tbl_board where no='$_GET[no]'"));
	$q[sub]=str_replace("<","&lt;",$q[sub]);
        $q[sub]=str_replace(">","&gt;",$q[sub]);
        $q[memo]=str_replace("<","&lt;",$q[memo]);
        $q[memo]=str_replace(">","&gt;",$q[memo]);

	// view
	if($q[no])
	{
		if($q[homepage]=="study" && $q[name]!=$_SESSION[id]) exit("<div id=error>��ȸ������ �����ϴ�</div>");
		if($q[cate]=="secret"){
					if($q[name]!=$_SESSION[id] && $_SESSION[id]!="admin") exit("<div id=error>��б� �Դϴ�.</div>");}

		if($_GET[mode]=="del" && $q[name]==$_SESSION[id])
		{
			@mysql_query("delete from tbl_board where no='$q[no]'");
			exit("<meta http-equiv=refresh content=0;url=?page=forum&id=$_GET[id]>");
		}

		if($_GET[mode]=="modify" && $q[name]==$_SESSION[id])
		{
			$date=date('Y-m-d H:i:s',time());

			if($_POST[sub] && $_POST[memo])
			{
				$_POST[sub]=htmlspecialchars($_POST[sub]);
				$_POST[memo]=htmlspecialchars($_POST[memo]);

				@mysql_query("update tbl_board set sub='$_POST[sub]',memo='$_POST[memo]',date='$date' where no='$q[no]'");
				exit("<meta http-equiv=refresh content=0;url=?page=forum&no=$q[no]&mode=modify&id=$_GET[id]>");
			}

	?>
<?php if(isset($_GET[id])) ?><form method=post action=?page=forum&no=<?=$_GET[no]?>&mode=modify><table cellpadding="0" cellspacing="0" width="990" align="center">
<?php if(!isset($_GET[id])) ?><form method=post action=?page=forum&no=<?=$_GET[no]?>&mode=modify&id=<?=$_GET[id]?>><table cellpadding="0" cellspacing="0" width="990" align="center">

                                <tr>
                                    <td width="990" height="41" background="images/common/forum_boardtopic.png">
                                        <p style="margin-right:5; margin-left:5;" align="center"><font color="white"><span
style="font-size:12pt;"><b><textarea rows=1 style=width:100%; name=sub><?=$q[sub]?></textarea></b></span></font></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" class="forumview2" valign="top">Category : <?=$q[cate]?></td>
                                    <td class="forumview2" valign="top">
                                        <p>Date : <?=$date?></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" class="forumview" valign="top">Username : <?=$q[name]?></td>
                                    <td class="forumview" valign="top">
<p><textarea name=memo style=width:100%;height:100%><?=$q[memo]?></textarea></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="990" height="10" background="images/common/forum_viewborder.png"></td>
                                </tr>
	<tr align=center><td><input type=submit value='Submit'></td></tr>
                            </table>

		<?php }

		if(!$_GET[mode]){

	        if($_POST[cmt])
	        {

			$cmt="<table cellpadding='0' cellspacing='0' width='990' align='center'><tr><td width='190' class='forumview' valign='top'><p>[$_SESSION[id]]</p><p>Date : ".date('Y-m-d H:i',time())."</p></td><td class='forumview' valign='top'>".html_($_POST[cmt])."</td></tr></table>\n";
			$cmt=addslashes($cmt);
        	        @mysql_query("update tbl_board set comment=concat(comment,'$cmt') where no='$_GET[no]'") or die(mysql_error());
			exit("<meta http-equiv=refresh content=0;url='?page=forum&no=$_GET[no]&id=$_GET[id]'>");
	        }

if($q[comment])
{
	$cmt_="";

	$cc=explode("\n",$q[comment]);

	for($i=0;$i<count($cc);$i++)
	{
		if(eregi("\[$_SESSION[id]\]",$cc[$i]))
		{
			$memo=strstr($cc[$i],"<td class='forumview' valign='top'>");
			$memo_bb=$cc[$i];
                        $memo2=strstr($cc[$i],"[$_SESSION[id]]</p>");
			$memo_b=$memo2;
			$memo2=str_replace(strstr($memo2,"</td>"),"",$memo2);
			$memo2=strstr($memo2,"Date : ");
			$memo2=str_replace("</p>","",$memo2);
			
			$memo=str_replace(strstr($memo,"</td>"),"",$memo);
			$memo=str_replace("<td class='forumview' valign='top'>","",$memo);

			if($_POST[sub]=="DEL" && $_POST[date] && $_POST[date]==md5($memo2))
			{
				$memo_bb=addslashes($memo_bb);
				mysql_query("update tbl_board set comment=replace(comment,'$memo_bb','') where no='$_GET[no]'");
				exit("<meta http-equiv=refresh content=0;url=?page=forum&no=$_GET[no]&id=$_GET[id]>");
			}
			/*
			if($_POST[cmt_modify] && $_POST[date] && $_POST[sub]=="Submit" && $_POST[date]==md5($memo2))
                        {
				$memo_b=addslashes($memo_b);
				$memo=addslashes($memo);
				$_POST[cmt_modify]=addslashes($_POST[cmt_modify]);
				$_POST[cmt_modify]=htmlspecialchars($_POST[cmt_modify]);
				$memo_c=str_replace(">$memo<",">$_POST[cmt_modify]<",$memo_b);
				mysql_query("update tbl_board set comment=replace(comment,'$memo_b','$memo_c') where no='$_GET[no]'") or die(mysql_error());
				exit("<meta http-equiv=refresh content=0;url=?page=forum&no=$_GET[no]&id=$_GET[id]>");
                        }
			*/
//		$cc[$i]=str_replace($memo,"<form method=post action=?page=forum&no=$_GET[no]&id=$_GET[id]><input type=hidden name=date value='".md5($memo2)."'><b>$memo</b>&nbsp;&nbsp;<input type=submit value='DEL' name=sub onclick='if(this.value==\"DEL\"){this.value=\"Really?\";return false}'></form>",$cc[$i]);
		}

		$cmt_.=$cc[$i];
	}

	$q[comment]=$cmt_;

}

?>
<table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="990" height="41" background="images/common/forum_boardtopic.png">
                                        <p style="margin-right:5; margin-left:5;" align="center"><font color="white"><span 
style="font-size:12pt;"><b><?=$q[sub]?></b></span></font></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" class="forumview2" valign="top">Category : <?=$q[cate]?></td>
                                    <td class="forumview2" valign="top">
                                        <p>Date : <?=$q[date]?></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" class="forumview" valign="top">Username : <?=$q[name]?></td>
                                    <td class="forumview" valign="top">
<p><?=$q[memo]?></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="990" height="10" background="images/common/forum_viewborder.png"></td>
                                </tr>
                            </table>

				<?=$q[comment]?>

                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" height="40" class="forumviewreply">
                                    </td>
                                    <td height="40" class="forumviewreply">
                                            <p>
                                            <form method=post action='?page=forum&no=<?=$_GET[no]?>'>
                                                <font color="white"><b>[<?=$_SESSION[id]?>] <input type=text name=cmt size=80><input type=submit 
value='Submit'></font>								</p>
                                        </form>
                                    </td>
                                </tr>
<?php }

	}

}

if(!$_GET[no])
{

if($_POST[sub] && $_POST[content])
{
	if($_GET[id]==$_SESSION[id]) $study="study";
	$_POST[sub]=sql_guard($_POST[sub]);
	$_POST[content]=sql_guard($_POST[content]);
	if($_POST[cate]!="free" && $_POST[cate]!="qna" && $_POST[cate]!="secret") $_POST[cate]="free";
	$get_num=mysql_fetch_array(mysql_query("select count(no) from tbl_board"));
	$get_num=$get_num[0]+1;
	@mysql_query("insert into tbl_board values('$get_num','$_SESSION[id]','$_SERVER[REMOTE_ADDR]','$_POST[sub]','$_POST[content]','0','','0',now(),'pwpw','$study','$_POST[cate]','0');") or die(mysql_error());
}

if(!isset($_GET['id'])) $limit=mysql_fetch_array(mysql_query("select count(no) from tbl_board where homepage<>'study'")); 
if(isset($_GET['id'])) $limit=mysql_fetch_array(mysql_query("select count(no) from tbl_board where homepage<>'study'"));
$limit=$limit[0]; 
if(!$limit) $limit=1;

if($limit>=10) 
{ 
	echo("<div align=left><font color=lightgreen></div>");
}
?>
<style> 
body, table, tr, td, p {font-weight:normal; font-size:9pt; line-height:15pt;} 
A:visited {color: white;text-decoration: none;} 
A:hover {color: white;text-decoration: underline;} 
A:active {color: red;text-decoration: none;} 
A:link {color: white;text-decoration: none; } 
</style> 

<?php
$pg=$limit/20; 
$pg=(int)$pg; 
if($limit/20>$pg) $pg++; 
$realpg=$_GET[p]; 
if(!$_GET[p]) $_GET[p]=$pg; 
$_GET[p]=($_GET[p]*20)-20; 
if(eregi("[^0-9]",$_GET[p])) exit(); 
$_POST[ca]=sql_guard($_POST[ca]); 
// search
if($_GET[ca]) $q=@mysql_query("select * from tbl_board where cate='$_GET[ca]' and homepage<>'study' limit 0,50"); 
if(!$_GET[ca]) $q=@mysql_query("select * from tbl_board where homepage<>'study' limit $_GET[p],20"); 
if(!$_GET[ca] && $_GET[search])
{
	$_GET[search]=str_replace("%","",$_GET[search]);
	if($_GET[search]) $q=mysql_query("select * from tbl_board where homepage<>'study' and sub like '%$_GET[search]%'");
}


?>
<div id=write_form class=msg style='display:none;'>
	<div id=msg style="background-image:url('images/common/forum_inputbg.png');">
		<form method=post action='?page=forum<?php if(isset($_GET[id])) { $_GET[id]=htmlspecialchars($_GET[id]); echo("&id=$_GET[id]"); }?>'>
		<font color=black>����<br><input type=text name=sub size=90 style=width:100%;><br><br>
		�з� <br>
<select name=cate>
	<option value='free' selected>free</option>
	<option value='qna'>qna</option>
	<option value='secret'>secret</option>
</select>
<br><br>
		���� <br><textarea cols=90 rows=5 name=content style=width:100%></textarea><br><br></font>
		<center><input type=image value='Submit' src="images/common/Btn_forum_submit.png" 
onmouseover='this.src="images/common/Btn_forum_submit_over.png"' onmouseout='this.src="images/common/Btn_forum_submit.png"' style="cursor:hand" 
border="0"> <input type=image value='Close' onclick=board_close(); src="images/common/Btn_forum_close.png" 
onmouseover='this.src="images/common/Btn_forum_close_over.png"' onmouseout='this.src="images/common/Btn_forum_close.png"' style="cursor:hand" 
border="0"></center>
		</form>
	</div>
</div>

<table id=board width=100%>
	<div align=right>
		<form method=get action='?page=forum' name=mv>
		<input type=hidden name=page value='forum'>
		<select name=ca  style=background:black;color:lightblue onchange=mv.submit()>"); 
			<option value='' <? if(!$_GET[ca]) echo("selected"); ?> >all</option> 
			<option value='free' <? if($_GET[ca]=='free') echo("selected"); ?> >free</option> 
			<option value='qna' <? if($_GET[ca]=='qna') echo("selected"); ?> >qna</option> 
			<option value='secret' <? if($_GET[ca]=='secret') echo("selected"); ?> >secret</option> 
		</select> 
		</form>
	</div>
<tr><td height=41 align='center' background='images/common/forum_boardbarbg.png'><font
color=white>No</font></td><td height=41 align='center' background='images/common/forum_boardbarbg.png'><font
color=white>Category</td><td height=41 align='center' background='images/common/forum_boardbarbg.png'><font
color=white>Username</td><td height=41 align='center' background='images/common/forum_boardbarbg.png'><font
color=white>Title</td><td height=41 align='center' background='images/common/forum_boardbarbg.png'><font
color=white>Date</td></tr>
<?php

$count=0; 
$i=0; 
// list

if(isset($_GET[id])) $q=mysql_query("select * from tbl_board where name='$_GET[id]' and homepage='study'");
while($data=@mysql_fetch_array($q)) 
{ 
	$data[memo]=html_($data[memo]);
	$data[sub]=html_($data[sub]);
	if($data[hit]>1000) $data[sub]="<font color=pink><b>$data[sub]"; 
	if($data[hit]>100) $data[sub]="<b>$data[sub]"; 
	$new_ck=date('Y-m-d',time()); 
	if(eregi($new_ck,$data[etc])) $data[commenct_c]="<b><font color=lightgreen>$data[commenct_c]</font></b>"; 

	$save[$i].="
<tr align=center height=25 bgcolor='36362b' onmouseover=this.style.background='gray' 
onmouseout=this.style.background='#36362b' onclick=location.href='?page=forum&no=$data[no]&id=$_GET[id]'><td width='5%'><font 
color=white>$data[no]</td><td width='10%'><font 
	color=white>$data[cate]</td><td width='15%'><font color=white>$data[name]</td><td align=center><font 
color=white>".$data[sub]."<font size=2><font color=yellow>$data[comment_c]</font></td><td width=20%><font 
	color=white>$data[date]</td></tr></tr>";
 
	$count++; 
	$i++; 
} 

for($i=count($save);$i>=0;$i--) echo($save[$i]); 

if(!$count) echo("<div style=width:900pt;>not found</div>");

?> 
</table>
<center> 
<?php

if(!$realpg) $realpg=$pg; 

$no=$realpg-10; 

if($no<0) $no=0; 

for($i=$pg;$i>$no;$i--) 
{ 
	if($i!=$realpg) echo("[<a href=?p=$i>$i</a>] "); 
	else echo("[$i] "); 
} 

if($no>=1) echo("..."); 
?> 
<br>
<center>
<form method=get action=index.php>
<input type=hidden name=page value='forum'>
<input type=text name=search style=width:90%><input type=submit value='Search'>
</form>
<div align=right>
<h3><a id=board_link onclick=board_write();>Write</a>&nbsp;&nbsp; 
</div>
<?php } 

if($_GET[no])
{
echo("<br><div align=right><h3>");
if($q[name]==$_SESSION[id] && !$_GET[mode]) echo("<a id=board_link onclick=location.href='?page=forum&no=$_GET[no]&mode=modify'>Modify</a>&nbsp;&nbsp;");
if($q[name]==$_SESSION[id] && !$_GET[mode]) echo("<a id=board_link onclick=location.href='?page=forum&no=$_GET[no]&mode=del'>Delete</a>&nbsp;&nbsp;");
echo("<a id=board_link onclick=history.go(-1);>Back</a>&nbsp;&nbsp;");
echo("</div>");

}

?>
