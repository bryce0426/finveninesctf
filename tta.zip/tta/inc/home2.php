	<script>
		$(function(){
			var startSlide = 1;
			$('#slides').slides({
				container: 'slide',
				pagination: true,
				generateNextPrev: true,
				next: 'next',
				prev: 'prev',
				generatePagination: true,
				paginationClass: 'page',
				start: 1,
				effect: 'slide',
				slideSpeed: 400,
				play: 3500,
				pause: 0,
				start: startSlide
			});
		});
	</script>
					<div id="slides" class="slides">
                                            <span class="slide" style="margin-left:0px; padding-top: 0px;">
                                                <li><a href="#"><img src="images/main/slide1.jpg" width="1000" height="250" alt="1"></a></li>
                                                <li><a href="#"><img src="images/main/slide2.jpg" width="1000" height="250" alt="2"></a></li>
                                            </span>
                                        </div>
                                        <!-- //slide --></td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="1000" height="20">&nbsp;</td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="1000" align="center">
                                <tr>
                                    <td width="500" height="25">
                                        <table cellpadding="0" cellspacing="0" width="500">
                                            <tr>
                                                <td width="400" height="35"><font face="����" color="white"><span style="font-size:9pt;"><img src="images/main/board_notice.png" width="200" height="25" border="0"></span></font></td>
                                                <td width="90">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;"><img src="images/main/board_btnmore.png" width="30" height="25" border="0"></span></font></p>
                                                </td>
                                                <td width="10"></td>
                                            </tr>

                                            <tr>

						<?php
						$q=mysql_query("select * from tbl_admin_notice order by reg_time desc limit 0,4");
						while($d=@mysql_fetch_array($q))
						{
						?>


                                              <td width="400" height="25" background="images/main/board_bg.png">

                                                  <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;cursor:pointer" 
onclick=location.href='?page=notice&no=<?=$d[reg_time]?>'><?=$d[reg_sub]?></span></font><font color="white"><span style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">| <?=date('Y/m/d',$d[reg_time])?></span></font><font face="����" color="white"><span 
style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
						<?php } ?>



<tr>
<!--
                                            <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
                                            <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
                                            <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
-->
                                        </table>
                                    </td>

                                    <td width="500" height="25">
                                        <table cellpadding="0" cellspacing="0" width="500">
                                            <tr>
                                                <td width="400" height="35"><font face="����" color="white"><span style="font-size:9pt;"><img src="images/main/board_now.png" width="200" height="25" border="0"></span></font></td>
                                                <td width="90">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;"><img src="images/main/board_btnmore.png" width="30" height="25" border="0"></span></font></p>
                                                </td>
                                                <td width="10"></td>
                                            </tr>
											<?php
										$q=mysql_query("select * from tbl_clear_log order by reg_time desc,reg_prob asc limit 0,4");
										while($d=mysql_fetch_array($q))
										{
									        echo('<tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span 
onclick=location.href="?page=login&user='.$d[reg_id].'" style="font-size:9pt;cursor:pointer;">'.$d[reg_id].'���� '.$d[reg_prob].'������ Ŭ���� 
�߽��ϴ�.</span></font><font color="white"><span style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png"></td>
                                                <td width="10" height="25"></td>
                                            </tr>');
										}
											?>
<!--
											     <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
-->
                                         </table>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="1000" align="center">
                                <tr>
                                    <td width="500" height="10">
                                        <p></p>
                                    </td>
                                    <td width="500" height="10">
                                        <p></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="500" height="27">
                                        <table cellpadding="0" cellspacing="0" width="500">
                                            <tr>
                                                <td width="400" height="35"><font face="����" color="white"><span style="font-size:9pt;"><img src="images/main/board_new.png" width="200" height="25" border="0"></span></font></td>
                                                <td width="90">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;"><img src="images/main/board_btnmore.png" width="30" height="25" border="0"></span></font></p>
                                                </td>
                                                <td width="10"></td>
                                            </tr>

<?php
$q=mysql_query("select name,sub,no,date from tbl_board where cate<>'secret' and homepage='' order by date desc limit 0,4") or die(1);
while($d=mysql_fetch_array($q))
{
	$d[date]=substr($d[date],0,11);
	$d[date]=str_replace("-","/",$d[date]);
	$d[sub]=str_replace("<","&lt;",$d[sub]);
        $d[sub]=str_replace(">","&gt;",$d[sub]);
	
	echo('										<tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;cursor:pointer;" 
onclick=location.href="?page=forum&no='.$d[no].'">'.$d[sub].'</span></font><font color="white"><span style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">| '.$d[date].'</span></font><font face="����" color="white"><span 
style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>');
}
?>
	


                                        </table>
                                    </td>
                                    <td width="500" height="55">
                                        <table cellpadding="0" cellspacing="0" width="500">
                                            <tr>
                                                <td width="400" height="35"><font face="����" color="white"><span style="font-size:9pt;"><img src="images/main/board_que.png" width="200" height="25" border="0"></span></font></td>
                                                <td width="90">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;"><img src="images/main/board_btnmore.png" width="30" height="25" border="0"></span></font></p>
                                                </td>
                                                <td width="10"></td>
                                            </tr>
			
		<?php
		$p=@mysql_fetch_array(mysql_query("select reg_no,reg_name from tbl_probs order by reg_no desc limit 1"));
			echo('                              <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;cursor:pointer">���� :'. $p[reg_no].'�� / �ֱ� �߰��� ���� : 
'.$p[reg_name].'</span></font><font color="white"><span style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">| '.date('Y-m-d').'</span></font><font face="����" color="white"><span style="font-size:9pt;"></span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>');
		?>
              
<!--                                           <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
                                            <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr>
                                            <tr>
                                                <td width="400" height="25" background="images/main/board_bg.png">
                                                    <p style="margin-right:5; margin-left:5;"><font face="����" color="white"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="90" height="25" background="images/main/board_bg.png">
                                                    <p align="center"><font face="����" color="#DEDEDE"><span style="font-size:9pt;">&nbsp;</span></font></p>
                                                </td>
                                                <td width="10" height="25"></td>
                                            </tr> -->
                                        </table>
                                    </td>
                                </tr>
                            </table>
