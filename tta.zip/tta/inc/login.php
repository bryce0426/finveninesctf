<?php
if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();

if(!$_SESSION[id])
{

	if($_POST[id] && $_POST[pw]) //to login
	{
		sleep(1);
		$tm=time();

		$_POST[id]=sql_guard($_POST[id]);
		$_POST[pw]=md5($_POST[pw]);
		
		$query=@mysql_fetch_array(mysql_query("select * from tbl_user where reg_id='$_POST[id]' and reg_pw='$_POST[pw]' and reg_auth=1"));
		if($query[reg_id])
		{
			$_SESSION[id]="$query[reg_id]";
			if(date('d',time())!=date('d',$query[reg_etc]))
			{
				@mysql_query("update tbl_user set reg_cash=reg_cash+1 where reg_id='$query[reg_id]'");
				@mysql_query("update tbl_user set reg_etc='$tm' where reg_id='$query[reg_id]'");
			}
			if($_GET['return'])
			{
				if(eregi("[^a-z]",$_GET['return'])) $_GET['return']="login";
				exit("<meta http-equiv=refresh content=0;url='?page=$_GET[return]'>");
			}
			if(!$_GET['return']) exit("<meta http-equiv=refresh content=0;url='?page=login'>");
		}
		else if($_POST[email])  //to register
		{
			{
				$_POST[email]=sql_guard($_POST[email]);
				$query=@mysql_fetch_array(mysql_query("select reg_id from tbl_user where reg_id='$_POST[id]'"));
				if($query[reg_id])
				{
					echo("<p id=error>�����ϴ� ���̵� �Դϴ�.</p>");
				}
				else if(!$query[reg_id])
				{
					if(eregi("'|\"",$_POST[id])) exit("<p id=error>���ʹ� �Է��Ͻ� �� �����ϴ�.</p>");
					@mysql_query("insert into tbl_user(reg_id,reg_pw,reg_ip,reg_email,reg_cash,reg_etc,reg_join,reg_cmt,reg_auth) values('$_POST[id]','$_POST[pw]','$_SERVER[REMOTE_ADDR]','$_POST[email]',0,0,'$tm','',0)");
					@mysql_query("insert into tbl_user_probs(reg_id,reg_score,reg_prob1,reg_prob2,reg_prob3,reg_prob4,reg_prob5,reg_prob6,reg_prob7,reg_prob8,reg_prob9,reg_prob10,reg_prob11,reg_prob12,reg_prob13,reg_prob14,reg_prob15,reg_prob16,reg_prob17,reg_prob18,reg_prob19,reg_prob20,reg_prob21,reg_prob22,reg_prob23,reg_prob24,reg_prob25,reg_prob26) values('$_POST[id]',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)") or die("error!");

					echo('                       <p align="center"><img src="images/common/Title_signup.png" width="500" height="70" border="0"></p>
											</td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" align="center">
										<tr>
											<td width="1000" height="500">
												<center>
													<div id=login>
														<form method=post action=index.php?page=login>
															<table cellpadding="0" cellspacing="0" align="center">
																<tr>
																	<td width="486"><img src="images/common/signup_01.png" width="486" height="177" border="0"></td>
																</tr>
																<tr>
																	<td width="486" background="images/common/signup_bg.png">
																		<table cellpadding="0" cellspacing="0" width="486">
																			<tr>
																				<td width="36">&nbsp;</td>
																				<td width="450">
																					<table cellpadding="0" cellspacing="0" width="450" height="73">
																						<tr>
																							<td width="240" height="25">&nbsp;</td>
																							<td width="200" height="25">&nbsp;</td>
																							<td width="10" height="25"><span style="font-size:9pt;">&nbsp;</span></td>
																						</tr>
																						<tr>
																							<td width="240" height="25">&nbsp;</td>
																							<td width="200" height="25">&nbsp;</td>
																							<td width="10" height="25"><span style="font-size:9pt;">&nbsp;</span></td>
																						</tr>
																						<tr>
																							<td width="240" height="23">
																								<p align="right"><span style="font-size:9pt;">&nbsp;</span></p>
																							</td>
																							<td width="200" height="23"><span style="font-size:9pt;"><a href="?page=login"><img src="images/common/Btn_main.png" width="100" height="25" border="0"></a></span></td>
																							<td width="10" height="23"><span style="font-size:9pt;">&nbsp;</span></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td width="486"><img src="images/common/loginbg_03.png" width="486" height="13" border="0"></td>
																</tr>
															</table>
														</form>
													</div>
					');
					exit();
				}
			}
		}
	}
?>
		<!-- Login -->

                                        <p align="center"><img src="images/common/Title_login.png" width="500" height="60" border="0"></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="1000" align="center">
                                <tr>
                                    <td width="1000" height="50">
                                        <p align="center"><img src="images/page/select_login.png" onclick=login.style.cssText='display:block;';signup.style.cssText='display:none;' width="111" height="29" border="0"> <img 
src="images/page/select_sign.png" 
onclick=login.style.cssText='display:none;';signup.style.cssText='display:block;' width="111" height="29" 
border="0"></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="1000" height="500">
                                        <center>
                                            <div id=login>
                                                <form method=post action=index.php?page=login&return=<?php if(!eregi("[^a-z]",$_GET['return'])) echo($_GET['return']);?>>
                                                    <p align="center">&nbsp;</p>
                                                    <table cellpadding="0" cellspacing="0" align="center">
                                                        <tr>
                                                            <td width="486"><img src="images/common/loginbg_01.png" width="486" height="177" border="0"></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="486" background="images/common/loginbg_02.png">
                                                                <table cellpadding="0" cellspacing="0" width="486">
                                                                    <tr>
                                                                        <td width="36">&nbsp;</td>
                                                                        <td width="450">
                                                                            <table cellpadding="0" cellspacing="0" width="450" height="73">
                                                                                <tr>
                                                                                    <td width="240" height="25">
                                                                                        <p align="right"><span style="font-size:9pt;">ID :</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="25">
                                                                                        <p style="margin:0;"><font color="#DEDEDE" face="Tahoma"><span style="font-size:8pt;"><INPUT type=text class=input_01 name=id style="padding:3px; width:130; height:20px; )';" /></span></font>
                                                                                    </td>
                                                                                    <td width="10" height="25"><span style="font-size:9pt;">&nbsp;</span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width="240" height="25">
                                                                                        <p align="right"><span style="font-size:9pt;">PASSWORD :</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="25">
                                                                                        <p style="margin:0;"><font color="#DEDEDE" face="Tahoma"><span style="font-size:8pt;"><INPUT type=password class=input_01 name=pw style="padding:3px; width:130; height:20px; )';" /></span></font>
                                                                                    </td>
                                                                                    <td width="10" height="25"><span style="font-size:9pt;">&nbsp;</span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width="240" height="23">
                                                                                        <p align="right"><span style="font-size:9pt;">&nbsp;</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="23"><span style="font-size:9pt;"><input type=submit style=background:url('images/common/Btn_login.png');width:100;height:25;border:0;background-repeat:repeat-x value=' ' name=cmd></a></span></td>
                                                                                    <td width="10" height="23"><span style="font-size:9pt;">&nbsp;</span></td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td width="486"><img src="images/common/loginbg_03.png" width="486" height="13" border="0"></td>
                                                        </tr>
                                                    </table>
                                                </form>
                                            </div>
		
                                            <div id=signup>
                                                <form method=post action=index.php?page=login>
                                                    <table cellpadding="0" cellspacing="0" align="center">
                                                        <tr>
                                                            <td width="486"><img src="images/common/signup_01.png" width="486" height="177" border="0"></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="486" background="images/common/loginbg_02.png">
                                                                <table cellpadding="0" cellspacing="0" width="486">
                                                                    <tr>
                                                                        <td width="36">&nbsp;</td>
                                                                        <td width="450">
                                                                            <table cellpadding="0" cellspacing="0" width="450" height="73">
																			<tr>
                                                                                    <td width="240" height="25">
                                                                                        <p align="right"><span style="font-size:9pt;">ID :</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="25">
                                                                                        <p style="margin:0;"><font color="#DEDEDE" face="Tahoma"><span style="font-size:8pt;"><INPUT type=text class=input_01 name=id style="padding:3px; width:130; height:20px; )';" /></span></font>
                                                                                    </td>
                                                                                    <td width="10" height="25"><span style="font-size:9pt;">&nbsp;</span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width="240" height="20">
                                                                                        <p align="right"><span style="font-size:9pt;">PASSWORD :</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="20">
                                                                                        <p style="margin:0;"><font color="#DEDEDE" face="Tahoma"><span style="font-size:8pt;"><INPUT type=password class=input_01 name=pw style="padding:3px;width:130; height:20px; )';" /></span></font>
                                                                                    </td>
                                                                                    <td width="10" height="25" rowspan="2"><span style="font-size:9pt;">&nbsp;</span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width="240" height="20">
                                                                                        <p align="right"><span style="font-size:9pt;">Email :</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="20">
                                                                                        <p style="margin:0;"><font color="#DEDEDE" face="Tahoma"><span style="font-size:8pt;"><br><INPUT type=text class=input_01 name=email style="padding:3px;width:130; height:20px; )';" /></span></font>
																					</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width="240" height="23">
                                                                                        <p align="right"><span style="font-size:9pt;">&nbsp;</span></p>
                                                                                    </td>
                                                                                    <td width="200" height="23"><input type=submit style=background:url('images/common/Btn_signup.png');width:100;height:25;border:0;background-repeat:repeat-x value=' ' name=cmd></td>
                                                                                    <td width="10" height="23"><span style="font-size:9pt;">&nbsp;</span></td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td width="486"><img src="images/common/loginbg_03.png" width="486" height="13" border="0"></td>
                                                        </tr>
                                                    </table>
                                                </form>
                                            </div>
                                        </center>
                                        </form>
                                    </td>
                                </tr>
                            </table>



		<!-- Login -->
<!--
		<center>
		<div id=login>
			<form method=post action=index.php?page=login>
			<p id=frm_title><input type=button value='Login' id=button>
			<input type=button onclick=login.style.cssText='display:none;';signup.style.cssText='display:block;' value='Signup'></p>
			<p id=frm_content>ID</p><input type=text name=id><br>
			<p id=frm_content>PW</p><input type=password name=pw>
			<br><br>
			<center><input type=submit name=cmd value='Login'></center>
			</form>
		</div>

		<div id=signup>
			<form method=post action=index.php?page=login>
			<p id=frm_title>
			<input type=button onclick=signup.style.cssText='display:none;';login.style.cssText='display:block;' value='Login'>
			<input type=button value='Signup' id=button>
			</p>	
			<p id=frm_content>ID</p><input type=text name=id>
<br>
			<p id=frm_content>PW</p><input type=password name=pw>
			<br>
			<p id=frm_content>Email</p><input type=text name=email>
			<br><center><input type=submit name=cmd value='Sign up'></center>
			</form>
		</div></center></form>
-->
<?php
}

if($_SESSION[id])
{
	if($_GET[mode]=="logout")
	{
		$_SESSION[id]="";
		echo('                                                    <p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_member.png" width="500" height="70" border="0"></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="990" height="500">
                                                    <p align="center"><img src="images/common/logout_text.png" width="449" height="60" border="0"></p>
                                                </td>
                                            </tr>
		');
		exit();
	}
	if($_POST[cmt] && strlen($_POST[cmt])<500)
	{
		$_POST[cmt]=sql_guard($_POST[cmt]);
		$_POST[cmt]=htmlspecialchars($_POST[cmt]);
		@mysql_query("update tbl_user set reg_cmt='$_POST[cmt]' where reg_id='$_SESSION[id]'");
		echo("<p id=msg>�ڸ�Ʈ�� ����Ǿ����ϴ�.</p><br>");
	}

	$_SESSION[id]=sql_guard($_SESSION[id]);
	$user=$_SESSION[id];
	if($_GET[user])
	{
		$_GET[user]=sql_guard($_GET[user]);
		user_check($_GET[user]);
		$user=$_GET[user];
	}

	$info=getinfo($user);
	$probs=getprobs($user);
	$info[reg_id]=htmlspecialchars($info[reg_id]);
	$info[reg_email]=htmlspecialchars($info[reg_email]);
	$info[reg_join]=date('Y-m-d H:i:s',$info[reg_join]);


//	echo("<form method=post action=index.php?page=login><p id=msg style=background:url('images/notebook.png')>$user");

?>
<form method=post action=index.php?page=login>
                                                    <p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_member.png" width="500" height="70" border="0"></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="990">
												
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg3.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><b><font color="white">[</font></b><font color="white"><span style="margin-right:10; margin-left:10;"><b><?=$user?></b></span></font><b><font color="white">] <?php if($user!=$_SESSION[id]) echo("���� �����Դϴ�"); ?></font></b></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">E-mail : <?=$info[reg_email]?></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">Comment : 
                                                            <INPUT name="cmt" type="text" size="50" value="<?=$info[reg_cmt]?>"><INPUT type="submit" value="Modify">	 </span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">Score : <?=$probs[reg_score]?></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">Cash : <?=$info[reg_cash]?></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">�����Ͻ� : <?=$info[reg_join]?></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">������ : <?=$info[reg_ip]?></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="20">
                                                            </td>
                                                        </tr>
                                                    </table>

<!-- 2015-02-05 -->
 <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg3.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white">����Ǯ�� ��Ȳ</font></b></p>
                                                            </td>
                                                        </tr>
                                                    </table>

 <table align="center" cellpadding="0" cellspacing="0" width="0" background="images/common/bar_bg2.png">
<td align=center width="960">
<?php
$probs = @mysql_fetch_array(mysql_query("select count(reg_no) from tbl_probs"));
$probs = $probs[0];
$get_probs = @mysql_fetch_array(mysql_query("select * from tbl_user_probs where reg_id='$user'"));
?>

<!-- 2015-02-05 -->
<?php
for($i=1;$i<=$probs;$i++)
{
	$get_probs_view = date('Y-m-d H:i',$get_probs['reg_prob'.$i]);
	$prob_info = @mysql_fetch_array(mysql_query("select reg_name,reg_page,reg_score from tbl_probs where reg_no='$i'"));

	if($get_probs['reg_prob'.$i])
	{
		$value = "$prob_info[reg_name]<br><font size=-2>Point:$prob_info[reg_score]<br><$get_probs_view></font>";
		echo("<button onmouseout=this.style.background='silver' onmouseover=this.style.background='#D5D5D5'; style='padding:10pt;width:110pt;height:60pt;background:silver;border:1pt solid black;border-radius:4pt;' onclick=location.href='$prob_info[reg_page]'>$value</button>");
//		echo("<input onmouseout=this.style.background='silver' onmouseover=this.style.background='#D5D5D5'; style='padding:10pt;width:110pt;height:60pt;background:silver;border:1pt solid black;border-radius:4pt;' type=button value='$value' onclick=location.href='$prob_info[reg_page]'>");
	}
	else
	{
		$value = "$prob_info[reg_name]<br>Point:$prob_info[reg_score]";
		echo("<button style='padding:10pt;width:110pt;background:gray;border:1pt solid black;border-radius:4pt;height:60pt;' onclick=location.href='$prob_info[reg_page]'>$value</button>");
	}
}
?>
</tr></table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
<tr><td height="10">&nbsp;</td></tr>
                                                            <td width="960">
                                                                <p align="right"><a href="?page=msg"><img src="images/common/Btn_member_message.png" 
onmouseover='this.src="images/common/Btn_member_message_over.png"' onmouseout='this.src="images/common/Btn_member_message.png"' style="cursor:hand" 
border="0">  </a><a href="?mode=logout&page=login"><img 
src="images/common/Btn_member_logout.png" onmouseover='this.src="images/common/Btn_member_logout_over.png"' onmouseout='this.src="images/common/Btn_member_logout.png"' style="cursor:hand"
border="0"></a></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
<?php

	echo("</p></form>");
}
?>
