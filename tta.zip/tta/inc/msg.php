<?php
if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();

getinfo($_SESSION[id]);

$_SESSION[id]=sql_guard($_SESSION[id]);

if($_GET[write]) user_check($_GET[write]);


if($_POST[id] && $_POST[msg])
{
	$tm=time();
	user_check($_POST[id]);
	$_POST[msg]=sql_guard($_POST[msg]);
	$_POST[msg]=str_replace("<","&lt;",$_POST[msg]);
	$_POST[msg]=str_replace(">","&gt;",$_POST[msg]);

		if($_POST[id]==$_SESSION[id]) exit("<div id=error>�ڱ� �ڽſ��Դ� �޼����� ���� �� �����ϴ�.</div>");

	mysql_query("insert into tbl_user_msg values('$tm','$_POST[id]','$_SESSION[id]','$_POST[msg]',0,0)") or die(mysql_error());

	echo("<div id=msg>�޼��� ���� �Ϸ�</div><br>");

}
?>
                                                    <p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_member.png" width="500" height="70" border="0"></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="990">
												
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg3.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><img src="images/common/icon_message.png" width="111" height="30" border="0"></p>
                                                            </td>
                                                        </tr>
                                                    </table><form method=post action=index.php?page=msg&mode=write>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="50" height="37">
                                                                <p align="left" style="margin-right:10; margin-left:10;"><font color="white"><span style="font-size:9pt; margin-right:5; margin-left:5;">&nbsp;ID :</span></font></p>
                                                            </td>
                                                            <td width="140" height="37"> <INPUT name="id" type="text" size="15" value='<?=$_GET[write]?>'>&nbsp;</td>
                                                            <td height="37"><INPUT name="msg" type="text" size="100"><INPUT type="submit" value="���� ����"></td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="20">
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
<?php

$q=mysql_query("select * from tbl_user_msg where reg_id='$_SESSION[id]' order by reg_time desc");
echo('
  <table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="20">
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table cellpadding="0" cellspacing="0" width="960" align="center">
                                                        <tr>
                                                            <td width="200" height="30" class="membermessage">
                                                                <p align="center">�ð�</p>
                                                            </td>
                                                            <td width="150" height="30" class="membermessage">
                                                                <p align="center">������</p>
                                                            </td>
                                                            <td height="30" class="membermessage">
                                                                <p align="center">����</p>
                                                            </td>
                                                        </tr>
                                                    </table>');

while($d=mysql_fetch_array($q))
{
	$tm=time();
	@mysql_query("update tbl_user_msg set reg_check='$tm' where reg_id='$_SESSION[id]'");
	$msg_tm=date('Y-m-d H:i',$d[reg_time]);
	echo(' <table cellpadding="0" cellspacing="0" width="960" align="center">
                                                        <tr>
                                                            <td width="200" height="30" class="membermessage2">
                                                                <p align="center">'.$msg_tm.'</p>
                                                            </td>
                                                            <td width="150" height="30" class="membermessage2">
                                                                <p align="center" onclick=location.href="?page=msg&write='.$d[reg_writer].'">'.$d[reg_writer].'</p>
                                                            </td>
                                                            <td height="30" class="membermessage2">
                                                                <p align="left">'.$d[reg_msg].'</p>
                                                            </td><td></td>
                                                        </tr>
                                                    </table>');

//	echo("<tr align=center><td>$msg_tm</td><td>$d[reg_writer]</td><td>$d[reg_msg]</td><td width=50><input type=button value='DEL' onclick=location.href='?page=msg&del_1=$d[reg_writer]&del_2=$d[reg_time]'></td></tr>");
}

echo("</table></div>");

?>

   <table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960">
                                                                <p align="right"><img src="images/common/Btn_forum_back.png" onmouseover='this.src="images/common/Btn_forum_back_over.png"'
onmouseout='this.src="images/common/Btn_forum_back.png"' style="cursor:hand" border="0" onclick=location.href='?page=login'></p>
                                                            </td>
                                                        </tr>
                                                    </table>
