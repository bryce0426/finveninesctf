</div>
<?php

if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();

if(!$_GET[no]) $_GET[no]=1;
if(eregi("[^0-9]",$_GET[no])) $_GET[no]=1;

$q=mysql_fetch_array(mysql_query("select * from tbl_admin_notice where reg_time='$_GET[no]'"));

$q[reg_time]=date('Y-m-d H:i:s',$q[reg_time]);

?><br>
<table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="990" valign="top" height="300">

<table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="990" height="41" background="images/common/forum_boardtopic.png">
                                        <p style="margin-right:5; margin-left:5;" align="center"><font color="white"><span 
style="font-size:12pt;"><b><?=$q[reg_sub]?></b></span></font></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" class="forumview2" valign="top">Category : free</td>
                                    <td class="forumview2" valign="top">
                                        <p>Date : <?=$q[reg_time]?></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="990" align="center">
                                <tr>
                                    <td width="190" class="forumview" valign="top">Username : admin</td>
                                    <td class="forumview" valign="top">
<pre><?=$q[reg_content]?></pre>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="990" height="10" background="images/common/forum_viewborder.png"></td>
                                </tr>
                            </table>
</table>
