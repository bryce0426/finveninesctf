<table cellpadding="0" cellspacing="0" width="990" style="margin-top:5; margin-bottom:5;" align="center">
                                            <tr>
                                                <td width="990">
                                                    <p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_rank.png" width="500" height="60" border="0"></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="990">
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="68">
                                                                <p><img src="images/common/bar_rank.png" width="960" height="68" border="0"></p>
                                                            </td>
                                                        </tr>
                                                    </table>
<?php

$q=mysql_query("select * from tbl_user_probs where reg_id <> 'admin' and reg_id<>'h9430' order by reg_score desc,reg_auth asc");
$max_challenges=mysql_fetch_array(mysql_query("select count(reg_no) from tbl_probs"));

$i=1;
while($d=mysql_fetch_array($q))
{
    $cnt = 0;

    for($j=1;$j<=$max_challenges[0];$j++)
    {
        $prob = "reg_prob".$j;
        if($d[$prob]!="0" && $d[$prob]!="") $cnt++;
    }

    if($cnt>0) $cnt=" <b>$cnt</b> <br>";
    else $cnt="";

    $d[reg_id]=sql_guard($d[reg_id]);
    $d[reg_id]=htmlspecialchars($d[reg_id]);
    $d[reg_score]=number_format($d[reg_score]);
    $d2=mysql_fetch_array(mysql_query("select reg_cmt from tbl_user where reg_id='$d[reg_id]'"));
    $cmt=$d2[reg_cmt];

    echo('<table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg.png">
                                                        <tr>
                                                            <td width="240" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;">'.$i.'</span></font></p>
                                                            </td>
                                                            <td width="240" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;"><a href="?page=login&user='.str_replace(" ","%20",$d[reg_id]).'">'.$d[reg_id].'</a></span></font></p>
                                                            </td>
                                                            <td width="240" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;">'.$cnt.$d[reg_score].'</span></font></p>
                                                            </td>
                                                            <td width="240" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;">'.$cmt.'</span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>');

//    echo("<tr align=center id=rank_row><td>$i</td><td><a style=color:blue href='?page=challenges&user=$d[reg_id]'>$d[reg_id]</a></td><td>$d[reg_score]</td><td>$cmt</td></tr>");
    $i++;
}

?>
</table>