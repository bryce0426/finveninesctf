<script>
function tool(val)
{
	tools.cmd.value=val;
	tools.submit();
}
</script>
<?php

$val="";

if($_POST[cmd] && $_POST[val])
{
	$_POST[val]=stripslashes($_POST[val]);

	if(eregi("</textarea",$_POST[val])) $_POST[val]=htmlspecialchars($_POST[val]);

	if($_POST[cmd]=="base64_encode") $_POST[val]=base64_encode($_POST[val]);
        if($_POST[cmd]=="base64_decode") $_POST[val]=base64_decode($_POST[val]);
        if($_POST[cmd]=="md5_hash") $_POST[val]=md5($_POST[val]);
        if($_POST[cmd]=="mysql_password")
	{
		$_POST[val]=addslashes($_POST[val]);
		$q=mysql_fetch_array(mysql_query("select password('$_POST[val]')"));
		$_POST[val]=$q[0];
	}

	if($_POST[cmd]=="mysql_old_password")
        {
                $_POST[val]=addslashes($_POST[val]);
                $q=mysql_fetch_array(mysql_query("select old_password('$_POST[val]')"));
                $_POST[val]=$q[0];
        }

        if($_POST[cmd]=="sha1_hash") $_POST[val]=sha1($_POST[val]);
        if($_POST[cmd]=="url_encode") $_POST[val]=urlencode($_POST[val]);
        if($_POST[cmd]=="url_decode") $_POST[val]=urldecode($_POST[val]);

	if($_POST[cmd]=="md5_crack")
	{
		echo("<a href=https://www.google.co.kr/?gws_rd=ssl#newwindow=1&q=$_POST[val] target=_blank>-- result</a>");
	}


	$val=$_POST[val];

}

?>
<table cellpadding="0" cellspacing="0" width="990" style="margin-top:5; margin-bottom:5;" align="center">
                                            <tr>
                                                <td width="990">
                                                    <p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_tools.png" width="500" height="60" border="0"></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="990" align="center">
                                                    <form method=post action='?page=tools' name=tools><input type=hidden name=cmd>
<textarea style=width:99%;height:100pt;background:url('images/notebook.png');color:green name=val><?=$val?></textarea>
<img src="images/tools/btn1.png" border="0" onclick=tool('base64_encode');>
<img src="images/tools/btn2.png" border="0" onclick=tool('base64_decode');>
<img src="images/tools/btn3.png" border="0" onclick=tool('md5_hash');>
<img src="images/tools/btn4.png" border="0" onclick=tool('md5_crack');>
<img src="images/tools/btn5.png" border="0" onclick=tool('mysql_password')>
<img src="images/tools/btn6.png" border="0" onclick=tool('mysql_old_password')>
<img src="images/tools/btn7.png" border="0" onclick=tool('sha1_hash')>
<img src="images/tools/btn8.png" border="0" onclick=tool('url_encode')>
<img src="images/tools/btn9.png" border="0" onclick=tool('url_decode')>
                                                    </form>
                                                </td>
                                            </tr>
                                        </table>

