
function board_write()
{
//	board.style.cssText="display:none;";
	write_form.style.cssText="display:block;";
}

function board_close()
{
//        board.style.cssText="display:block;";
        write_form.style.cssText="display:none;";
}

function unload_check()
{
	if(document.URL.indexOf("write")!=-1)
	{
		var ck=confirm('Really?');
		if(ck==false) return false;
		else return true;
	}
}


function c_view(val,c_)
{

	challenges_all.style.cssText='display:none';
	challenges_sql.style.cssText='display:none';
	challenges_xss.style.cssText='display:none';
	challenges_fu.style.cssText='display:none';
	challenges_code.style.cssText='display:none';
	challenges_etc.style.cssText='display:none';
        challenges_fd.style.cssText='display:none';
        challenges_basic.style.cssText='display:none';
        challenges_js.style.cssText='display:none';
        challenges_para.style.cssText='display:none';
        challenges_lfi.style.cssText='display:none';
        challenges_rfi.style.cssText='display:none';
        challenges_ck.style.cssText='display:none';
        challenges_guess.style.cssText='display:none';
        challenges_php.style.cssText='display:none';
        challenges_reg.style.cssText='display:none';
        challenges_dec.style.cssText='display:none';
        challenges_xml.style.cssText='display:none';
        challenges_stego.style.cssText='display:none';
        challenges_shell.style.cssText='display:none';
        challenges_serial.style.cssText='display:none';
        challenges_uni.style.cssText='display:none';
        challenges_sess.style.cssText='display:none';

	target_=eval("challenges_"+val.toLowerCase());
	target_.style.cssText="display:block";
}

function slider()
{
	$(function(){
		var $list = $(".slider_list");
		var $box = $(".slider_box");
		var wd = $list.width();
		var num = $list.size();
		var margin,current,play;
		$box.width(wd*num);
		for(i=0; i<num; i++){
			var nav = '<a href="#" title="'+(i+1)+'��°�� �̵�"></a>'
			$(".slider_nav").append(nav);
		};
		var $nav = $(".slider_nav a");
		$(".slider_nav a:first").addClass("on");
		setTimeout(function(){
			play = setInterval(play_next,5000);
		},3000)
		$(".slider_wrap").hover(function(){
			$(".prev,.next").show();
		},function(){
			$(".prev,.next").hide();
		});
		function play_next(){
			margin = parseInt($box.css("margin-left"));
			if(margin < -(wd*(num-2))){
				$box.not(":animated").animate({"marginLeft":"0px"},"fast");
			}else{
				$box.not(":animated").animate({"marginLeft":"-="+wd+"px"},"fast");
			};
			var current = Math.abs(Math.floor(margin/wd));
			$nav.removeClass("on");
			$nav.eq((current-num)+1).addClass("on");
		}
		function play_prev(){
			clearInterval(play);
			margin = parseInt($box.css("margin-left"));
			if(margin == 0){
				$box.not(":animated").animate({"marginLeft":"-"+wd*(num-1)+"px"},"fast");
			}else{
				$box.not(":animated").animate({"marginLeft":"+="+wd+"px"},"fast");
			};
			var current = Math.abs(Math.floor(margin/wd));
			$nav.removeClass("on");
			$nav.eq(current-1).addClass("on");
		}
		$(".next").click(function(){
			clearInterval(play);
			play_next();
			return false;
		});
		$(document).keydown(function(evt){
			if (evt.keyCode==37){
				play_prev();
			}else if(evt.keyCode==39){
				clearInterval(play);
				play_next();
			}
		});
			$(".prev").click(function(){
			play_prev();
			return false;
			});

		$nav.click(function(){
			clearInterval(play);
			$nav.removeClass("on");
			$(this).addClass("on");
			$box.not(":animated").animate({
				"marginLeft":-wd*($(this).index())
			});
			return false;
		});
	});
}

function notice()
{
$(document).ready(function() {
    var triggers = $(".noticeInput").overlay({
      mask: {
        color: 'silver',
        loadSpeed: 1000,
        opacity: 1.0
      },
      closeOnClick: false
  });
});

}

function challenge()
{
$(document).ready(function() {
    var triggers = $(".modalInput").overlay({
      mask: {
        color: 'gray',
        loadSpeed: 500,
        opacity: 0.9
      },
      closeOnClick: false
  });
 
     var triggers = $(".modalInput_clear").overlay({
      mask: {
        color: 'lightblue',
        loadSpeed: 100,
        opacity: 0.9
      },
      closeOnClick: false
  });

  });
}

function calendar()
{
$(document).ready(function() {
    var triggers = $(".calendarInput").overlay({
      mask: {
        color: 'silver',
        loadSpeed: 100,
        opacity: 0.8
      },
      closeOnClick: false
  });
});

}
