<?php
@session_start();
foreach($_GET as $no=>$val) $para.= "$no=".urlencode($val)." ";
foreach($_POST as $no=>$val) $para.= "$no=".urlencode($val)." ";
foreach($_COOKIE as $no=>$val) $para.= "$no=".urlencode($val)." ";

$log_tm = date('Y-m-d H:i:s',time());
$log = "[$log_tm]$_SESSION[id]($_SERVER[REMOTE_ADDR]) $_SERVER[REQUEST_METHOD] $_SERVER[SCRIPT_NAME] [p] ".$para."\n";
$log = htmlspecialchars($log);

$log_path = "/var/www/c0ntro1/LOG/";

if(!@file($log_path."log.php"))
{
        $f=@fopen($log_path."log.php","w");
        @fwrite($f,"<?p"."hp exit(); ?>\n");
        @fclose($f);
}

$f=@fopen($log_path."log.php","a");
@fwrite($f,$log);
@fclose($f);


?>
