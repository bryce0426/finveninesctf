-- create a table
CREATE TABLE user (
    no INTEGER PRIMARY KEY,
  id TEXT NOT NULL,
  pw TEXT NOT NULL
);

-- insert some values
INSERT INTO user VALUES (1, 'guest', 'guest');
INSERT INTO user VALUES (2, 'admin', 'sdgsdgsdg');

-- fetch some values
SELECT * FROM user WHERE id='guest' and pw='guest';