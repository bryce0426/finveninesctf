<?

$cnt = 0;

function insert_db($naver_id)
{
	mysql_connect("localhost","root","t1ger") or die("connection error");
	mysql_select_db("wargame");

	$query = @mysql_fetch_array(mysql_query("select naver_id from tbl_user where naver_id='$naver_id'"));
	
	if(!$query[naver_id])
	{		
		$sql = "insert into tbl_user (naver_id) values ('$naver_id')";
		mysql_query($sql) or die($sql);
	}
	else
	{
		echo "it's exist. passed\r\n";
	}
}

function insert_member($buf)
{
	GLOBAL $cnt;
	
	$data = explode(" ", $buf);
	$naver_id = substr($data[1], 1, strlen($data[1])-2);
	
	insert_db($naver_id);
	echo $cnt . " : " . $naver_id . "<br>";
	$cnt++;
}

$handle = @fopen("./memberlist.txt", "r");
if ($handle) {
    while (($buffer = fgets($handle, 4096)) !== false) {
        insert_member(trim($buffer));
    }
    if (!feof($handle)) {
        echo "Error: unexpected fgets() fail\n";
    }
    fclose($handle);
}


?>