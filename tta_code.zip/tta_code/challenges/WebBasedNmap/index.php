<html>
<head>
<title>web based nmap</title>
</head>
<body>
<?php
    $ip = $_GET['ip'];

    $cmd = "nmap -p 1-1024 $ip";
    $arr = array(";", "|", "&", "\$", "!", "`", "[", "(", "^", "php", "/","..","\\","*");

    foreach($arr as $chr)
    {
        if(strstr($cmd, $chr))
        {
            echo("do not hack!");
            exit;
        }
    }

    echo("<pre>$cmd");
    system($cmd);
    // pw.cgi
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
