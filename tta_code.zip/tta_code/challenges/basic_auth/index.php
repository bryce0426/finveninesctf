<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_meth0d");
echo("Password is $password");
?>
