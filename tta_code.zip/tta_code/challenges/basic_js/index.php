<?php
$check=md5("$_SERVER[REMOTE_ADDR]".time());
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_goodjs!");

if($_GET[id]=="admin" && $_GET[pw]=="goodjs")
{
	echo("Password is $password");
	exit();
}
?>
<html>
<head>
<style type="text/css">
body { background:black; color:lightgreen; font-size:10pt; padding:10pt;}
.content { background:#007087; }
</style>
<script type="text/javascript" src="js.php?check=<?=$check?>"></script>
<title>Basic JS</title>
</head>
<body>
<form name=login_frm>
<table border=0 align=center cellpadding=10>
<tr><td class=content>userid</td><td><input type=text name=id size=10 maxlength=10></td></tr>
<tr><td class=content>password</td><td><input type=password name=pw size=10 maxlenght=10></td></tr>
<tr><td colspan=2 align=center><input type=button value='Login' onclick=login();></td></tr>
</table>
</form>
</form>
</body>
</html>
