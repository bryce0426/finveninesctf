<?php
if($_GET[check]!=md5("$_SERVER[REMOTE_ADDR]".time())) exit();
?>


















































function login()
{
	var hidden_id = login_frm.id.value;
	var hidden_pw = login_frm.pw.value;

	if(hidden_id=="admin" && hidden_pw=="goodjs")
	{
		location.href='?id=admin&pw=goodjs';
	}

	else
	{
		alert('Wrong');
	}

}
