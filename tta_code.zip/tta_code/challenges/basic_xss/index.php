<html>
<head>
<style type="text/css">
body { background:#EAEAEA; }
#game { width:100%; height:90%; border:0; }
input[type=text] { width:90%; }
input[type=submit] { width:10%; }
div { border-bottom:1pt solid white; }
</style>
<title>Basic XSS</title>
</head>
<body>
<?php
$token = sha1("$_SERVER[REMOTE_ADDR]_hehe!sheshe".time());
?>
<div align=right>
<input type=text value='game.php?token=<?=$token?>' readonly><input type=submit value='GO'></div>
<iframe src=game.php?token=<?=$token?> id=game></iframe>
</body>
</html>
