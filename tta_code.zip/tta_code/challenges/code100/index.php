<?php
header("Content-Type: text/html;charset=euc-kr");
?>
<html>
<head>
<style type="text/css">
body { margin:0 auto;padding:20pt; background:black; color:lightgreen; 
text-align:center; }
input { background:black; color:lightgreen; }
input[type=text] { text-align:center; }
</style>
<title>CODE 100</title>
</head>
<body>
<?php
if($_GET[brute_force_me])
{
	if(eregi("[^0-9]",$_GET[brute_force_me])) { sleep(1); exit("���ڸ� �Է��Ͻ� �� �ֽ��ϴ�"); }
	if($_GET[brute_force_me]>999) { sleep(1); exit("999������ ���� �Է����ּ���"); }
	if($_GET[brute_force_me]=="587")
	{
		$password=md5("$_SERVER[REMOTE_ADDR]_tiger_coddd100");
		echo("Password is $password");
	}
	else echo("Wrong password");
echo("<br>");
}

?>
<form method=get action=index.php>
PASSWORD : <input type=text name=brute_force_me size=4 maxlength=4><input type=submit>
</form>
</body>
</html>
