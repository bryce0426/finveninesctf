<?php @session_start(); ?>
<html>
<head>
<title>CODE 120</title>
</head>
<body>
<?php
if($_POST[pw])
{
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_coddd120eeee0e");

	if(!$_COOKIE[check]) exit("access denied");

	if(eregi("[^0-9]",$_POST[pw])) exit();
	if($_POST[pw]>1000) exit();

	if($_POST[pw]==890)
	{
		echo("Password is $password");
		exit();
	}

	else echo("Wrong");
}
?>
<form method=post action=index.php>
Password<br><br>
<input type=text name=pw maxlength=3><br><br>
<input type=submit>
</form>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
