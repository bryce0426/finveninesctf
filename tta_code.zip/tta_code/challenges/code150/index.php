<html>
<head>
<style type="text/css">
* { padding:10pt; margin:0 auto; text-align:center; }
body { background:#363636; color:white; }
input { border:0; }
</style>
<title>CODE 150</title>
</head>
<body>
<?php
$user=md5($_SERVER[REMOTE_ADDR]);
$f=@file("tmp/".$user);

if(!$f)	echo("<input type=button value='Start' onclick=location.href='?mode=start'>");
if(!$f && $_GET[mode]=="start")
{
	$f=fopen("tmp/".$user,"w");
	fwrite($f,"1\n1234");
	fclose($f);
	exit("<meta http-equiv=refresh content=0;url=index.php>");
}

if($f)
{
	if($f[0]>=100)
	{
                $password=md5("$_SERVER[REMOTE_ADDR]_tiger_run2u");
		echo("Password is $password");
		system("rm -f tmp/".$user);
		exit();

	}

	if($_GET[pw]==$f[1])
	{
		$pw=md5("password".rand(1,1000));
		$cnt=$f[0]+1;
		$f=fopen("tmp/".$user,"w");
		fwrite($f,"$cnt\n$pw");
		fclose($f);
		exit("<meta http-equiv=refresh content=0;url=index.php>");
	}

	echo("<font size=2>hi $_SERVER[REMOTE_ADDR]!<br>");
	echo("$f[0]/100<br>");
	echo("<form method=GET action=index.php>password is <input type=button value='?' onclick=alert('$f[1]')> : <input type=text name=pw><input type=submit></form>");
}

?>
</body>
</html>
