<html>
<head>
<title>CODE 50</title>
</head>
<body>
<?php
$tm=time();
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_codejavascr1pt@");

	for($i=0;$i<=20;$i++)
	{
		$spam.=chr(rand(97,122));
	}
if($_GET[spam] && $_GET[spam_check] && $_GET[tm])
{
	if($_GET[tm]<$tm-2) exit("timeout");

	if(strlen($_GET[spam])<20) exit("spam_checker error");
	if($_GET[spam]!=$_GET[spam_check]) exit("spam_checker error");

	if($_GET[spam]==$_GET[spam_check])
	{
		echo("Password is $password");
	}

}
?><br><br>
<form method=get action=index.php>
spam checker<br>
<input type=hidden name=spam value='<?=$spam?>'>
<input type=button value='<?=$spam?>' style=background:#363636;color:white;font-size:9pt;text-align:center;width:200pt;><br>
<input type=text name=spam_check style=width:200pt;>

<input type=hidden name=tm value='<?=$tm?>'>
<br><br>
<input type=submit>
</form>
<script>
setTimeout("document.forms[0].elements[0].value='Time out'",2000);
</script>
</body>
</html>
