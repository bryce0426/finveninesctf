<?php @session_start(); ?>
<html>
<head>
<title>Control 4</title>
</head>
<body>
<?php
if(!$_SESSION[control4])
{
    $sec=date('s',time());
    if($sec<10) $sec=10;

    if($_GET[mode]=="login" && isset($_GET[id]))
    {
        if(strlen($_GET[id])!=32) exit("error");

        for($i=0;$i<=60;$i++) if(md5($i."guest")==$_GET[id]) $true="guest";
                for($i=0;$i<=60;$i++) if(md5($i."admin")==$_GET[id]) $true="admin";

        if(!$true) exit("no");
        $_SESSION[control4]="$true";
        exit("<meta http-equiv=refresh content=0;url=index.php>");        
    }

    if(isset($_POST[id]) && isset($_POST[pw]))
    {
        if(eregi("admin",$_POST[id])) exit("Access Denied");
        $id=md5($sec."$_POST[id]");
        exit("<meta http-equiv=refresh content=0;url=?mode=login&id=$id>");
    }

    echo("<form method=post action=index.php>user_id<br><input type=text name=id value='guest'><br><br>password<br><input type=password name=pw value='guest'><br><br><input type=submit></form>");
}

if($_SESSION[control4])
{
    $password=md5("$_SERVER[REMOTE_ADDR]_tiger_c0ntROL4f1AGG@");
    if($_GET[mode]=="logout")
    {
        $_SESSION[control4]="";
        exit("<meta http-equiv=refresh content=0;url=index.php>");
    }
    echo("hi $_SESSION[control4]");
    if($_SESSION[control4]=="admin" && $_GET[mode]=="admin") echo("<br>Password is $password<br>");
    if($_SESSION[control4]!="admin" && $_GET[mode]=="admin") echo("<br>Access denied<br>");
    echo("<br><br><a href=?mode=admin>admin page</a><br><br><a href=?mode=logout>logout</a>");
}
?>
</body>
</html>