<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_ezcook1e");

if(!$_COOKIE[user_id])
{
	SetCookie("user_id","guest");
	exit("<a href=index.php>refresh</a>");
}
?>
<html>
<head>
<title>Cookie 1</title>
</head>
<body>
<?php
if($_GET[mode]=="admin")
{
	if($_COOKIE[user_id]!="admin") echo("you are not admin<br><br>");
	else echo("password is $password<br><br>");
}
?>
hi <?php echo(htmlspecialchars("$_COOKIE[user_id]"));?><br><br>
<a href=?mode=admin>admin page</a>

</body>
</html>
