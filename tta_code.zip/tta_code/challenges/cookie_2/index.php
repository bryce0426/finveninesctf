<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_bAS274zz");

	function enc_($val)
	{
		$val=base64_encode($val);
		$val=str_replace("a",'!',$val);
		$val=str_replace("b",'@',$val);
                $val=str_replace("c",'#',$val);
                $val=str_replace("d",'$',$val);
                $val=str_replace("e",'%',$val);
                $val=str_replace("f",'^',$val);
                $val=str_replace("g",'&',$val);
                $val=str_replace("h",'*',$val);
                $val=str_replace("i",'(',$val);
                $val=str_replace("j",')',$val);
		$val=base64_encode($val);
		return $val;
	}

	function dec_($val)
	{
		$val=base64_decode($val);
		$val=str_replace(')',"j",$val);
                $val=str_replace('(',"i",$val);
                $val=str_replace('*',"h",$val);
                $val=str_replace('&',"g",$val);
                $val=str_replace('^',"f",$val);
                $val=str_replace('%',"e",$val);
                $val=str_replace('$',"d",$val);
                $val=str_replace('#',"c",$val);
                $val=str_replace('@',"b",$val);
                $val=str_replace('!',"a",$val);
		$val=base64_decode($val);
		return $val;
	}

if($_COOKIE[user_id] && $_GET[mode]=="logout")
{
	SetCookie("user_id","");
	exit("<meta http-equiv=refresh content=0;url=index.php>");
}


if($_POST[user_id] && $_POST[user_pw] && !$_COOKIE[user_id])
{
	if($_POST[user_id]=="admin") exit("Access Denied");
	$_POST[user_id]=enc_($_POST[user_id]);
	SetCookie("user_id","$_POST[user_id]");
	exit("<meta http-equiv=refresh content=0;url=index.php>");	
}


?>
<html>
<head>
<title>Cookie 2</title>
</head>
<body>
<?php
if(!$_COOKIE[user_id])
{
	echo("<form method=post action=index.php><table border=1 cellpadding=10><tr><td>user_id</td><td><input type=text name=user_id></td></tr>
<tr><td>user_pw</td><td><input type=text name=user_pw></td></tr><tr><td colspan=2 align=center><input type=submit></td></tr></table></form>");
}
else
{
	$user_id=dec_($_COOKIE[user_id]);
	if(!$user_id) exit("Access Denied");
	echo("hi! ".htmlspecialchars($user_id)."<br><input type=button value='logout' onclick=location.href='?mode=logout'><!--user_id = admin-->");
	if($user_id=="admin")
	{
		echo("<br>password is $password");
	}
}
?>
</body>
</html>
