<?php
if($_POST[id] && !$_COOKIE[user_id])
{
	if(eregi("admin",$_POST[id])) exit("Access Denied");
	$ck=md5($_POST[id]);
	$ck=base64_encode($ck);
	setCookie("user_id",$ck);
	exit("<meta http-equiv=refresh content=0;url=index.php>");
}
?>
<html>
<head>
<title>Cookie 3</title>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_md5idmd5nullsha1id");

if(!$_COOKIE[user_id])
{
	echo("<form method=post action=index.php><input type=text name=id value='guest'><input type=submit></form>");
}

else
{
	$ck=base64_decode($_COOKIE[user_id]);
	if(md5("guest")==$ck)
	{
		echo("hi! guest<br><br>guest -> admin");
	}

	else if(md5("admin")==$ck)
        {
                echo("hi! admin<br><br><b>Password is $password</b>");
        }

	else
	{
		echo("<font color=red>user_id error</font>");
	}

}
?>
</body>
</html>
