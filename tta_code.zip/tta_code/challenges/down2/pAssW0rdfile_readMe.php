<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_d0wnloadchallengec1ear");
echo("Password is $password");
?>
