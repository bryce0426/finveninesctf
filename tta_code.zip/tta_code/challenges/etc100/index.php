<html>
<head>
<style type="text/css">
body { background:#6F6F6F; color:white; padding:5pt; text-align:center; font-size:10pt;}
input{ width:100pt; }
input[type=text] { color:green; }
input[type=submit]:hover { font-weight:bold;  }
a { color:black; }
</style>
<title>ETC 100</title>
</head>
<body>
<?php

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_chatadmin~~@");

function login__($val)
{
	$val=explode(':',$val);
	for($i=0;$i<count($val);$i++)
	{
		$result=base64_decode($val[$i]);
		$result=hexdec($result);
		$result=chr($result);
		$info.=$result;
	}

	return $info;
}

function login_($val)
{
	for($i=0;$i<strlen($val);$i++)
	{
		$result.=base64_encode(bin2hex(substr($val,$i,1))).":";
	}

	return $result;
}

if($_GET['login'])
{
	$id = login__($_GET['login']);
	$id = trim($id);

	if(!$id) exit("Access Denied");
	if($id)
	{
		echo("hi ".htmlspecialchars($id)."<br><br>");
		if($id=="admin") echo("Password is $password");
	}
	echo("<br><br><a href=index.php>index.php</a>");
	exit();
}

if(!$_POST['login']) echo("<form method=post action=index.php>&lt; ID &gt;<br><input type=text name=login value='admin'><br><br><input type=submit></form>");
if($_POST['login'])
{
	if(eregi("admin",$_POST['login'])) exit("Access Denied");
	if(eregi("a",$_POST['login'])) exit("Access Denied - a");
        if(eregi("d",$_POST['login'])) exit("Access Denied - d");
        if(eregi("m",$_POST['login'])) exit("Access Denied - m");
        if(eregi("i",$_POST['login'])) exit("Access Denied - i");
        if(eregi("n",$_POST['login'])) exit("Access Denied - n");

	$id = login_($_POST['login']);
	exit("<meta http-equiv=refresh content=0;url='?login=$id'>");
}
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
