<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_guess2adminpageguess2@__");

echo("Password is $password");

?>
