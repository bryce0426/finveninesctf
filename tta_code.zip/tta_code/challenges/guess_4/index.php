<html>
<head>
<style type="text/css">
body { background:black; color:lightgreen; font-size:20pt; }
</style>
<title>guess 4</title>
</head>
<body>
<?php
if($_GET[pw]=="adminauth")
{
	$password="vimvimblackout";
	echo("hi admin!<br>Password is $password");
}
else echo("Access denied");
?>
</body>
</html>
<!--
hint

vim
-->
