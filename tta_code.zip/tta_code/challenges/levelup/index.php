<?php
if(!$_COOKIE[lv])
{
	setCookie("lv",1);
	exit("<meta http-equiv=refresh content=0;url=index.php>");
}
?>
<html>
<head>
<title>level up</title>
<style type="text/css">
body { background:#636363; color:white; text-align:center; font-size:20pt; padding:20pt; maring:0 auto;}
a { color:silver; }
a:hover{ color:white; }
</style>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_1evelUP2.5");

$lv=$_COOKIE[lv];

echo("*LV : ".htmlspecialchars($lv)."*<br>");

if($lv>=3) exit("Access Denied");
if($lv>2) echo("Password is $password");
?>
<br><a href=index.phps>index.phps</a>
</body>
</html>
