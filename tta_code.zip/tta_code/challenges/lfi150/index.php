<html>
<head>
<title>LFI 150</title>
</head>
<body>
<?php

$ip=md5("$_SERVER[REMOTE_ADDR]");
$tm=date('m-d H:i',time());

$f=@fopen("logs/$ip","a");
@fwrite($f,"[$tm] $_SERVER[HTTP_USER_AGENT]\n");
@fclose($f);

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_LFI150logfileInc1ud2");

	if($_GET[file])
	{
		if(substr($_GET[file],0,1)=="/") exit("Access Denied");
		if(eregi("\.\.|:",$_GET[file])) exit("Access Denied");
		if(strlen($_GET[file])>50) exit("Access Denied");
		if($_GET[file]=="test") include "test";
		if($_GET[file]=="hi") include "hi";
		if($_GET[file]=="logs/$ip")
		{
			$f=@file("logs/$ip");
			for($i=count($f);$i>=count($f)-10;$i--)
			{
				if(eregi("<\?",$f[$i])){
				if(eregi("system|`|pass|exe",$f[$i])){
				echo("Password is $password");}}
				echo(htmlspecialchars($f[$i])."<br>");
			}
		}
	}

	else
	{
		echo("<a href=?file=test>test</a><br>");
		echo("<a href=?file=hi>hi</a><br>");
	}

?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
