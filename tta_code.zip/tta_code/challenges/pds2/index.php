<html>
<head>
<title>PDS 2</title>
<style type="text/css">
body { background:silver; color:black; font-size:10pt; padding:5pt; }
</style>
</head>
<body>
<?php

$upload=md5("$_SERVER[REMOTE_ADDR]__pds2");
$f=@file("uploads/$upload/check");
if(!$f)
{
	system("mkdir uploads/$upload");
	$f=@fopen("uploads/$upload/check","a");
	@fwrite($f,"$_SERVER[REMOTE_ADDR]");
	@fclose($f);
	system("cp uploads/index.php uploads/$upload/index.php");
}

if(!$_FILES[upfile])
{
	$ff=@file("uploads/.htaccess");
	for($i=0;$i<=count($ff);$i++)
	{
		$ff2.=$ff[$i];
	}

	if(eregi("engine",$ff2))
	{
		system("rm -f uploads/.htaccess");
	}
}

$pw=
'
<?php
	// password is engine_0ff!
	echo("READ ME");
?>
';

@exec("ls uploads",$cnt);
if(count($cnt)>=100)
{
	@system("rm -f uploads/*");
	$f=@fopen("uploads/index.php","w");
	@fwrite($f,$pw);
	@fclose($f);
}


if($_FILES[upfile])
{
	$up_tmp=$_FILES['upfile']['tmp_name'];
	$up_name=$_FILES['upfile']['name'];

	if(eregi("php|html|cgi|index",$up_name)) $up_name=md5("$up_name".time());
	$up_name=htmlspecialchars($up_name);
	$up_name=addslashes($up_name);

	$f=@file($up_tmp);

	for($i=0;$i<=count($f);$i++) $file.=$f[$i];

	if(eregi("<|>|\?|`",$file)) exit("Access Denied");
	if(strlen($file)>=20) exit("Access Denied");

	$file=htmlspecialchars($file);
	$file=addslashes($file);

	$f=fopen("uploads/$upload/$up_name","w") or die("upload error");
	fwrite($f,$file);
	fclose($f);

	echo("Done!<br><a href='uploads/$upload/$up_name'>$up_name</a>");
}

?>
<p>File upload 2</p>
<form method=post action=index.php enctype=multipart/form-data>
<input type=file name=upfile><input type=submit><br><br>
<a href=uploads/<?=$upload?>/index.php>read me</a>
</form>
</body>
</html>
