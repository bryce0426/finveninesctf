<html>
<head>
<title>PHP 2</title>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_g2tp0STc0oKiE@");
if($_GET[get] && $_POST[post] && $_COOKIE[cookie])
{
	echo("Password is $password");
}

else echo("Wrong");
?>
<br><a href=index.phps>index.phps</a>
</body>
</html>
