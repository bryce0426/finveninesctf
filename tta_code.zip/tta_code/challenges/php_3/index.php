<html>
<head>
<title>PHP 3</title>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_hashmd5ShA1encodeBaSE64@");

if(md5(sha1(base64_encode($_SERVER[REMOTE_ADDR])))==$_GET[myip])
{
	echo("Password is $password");
}

else
{
	echo("Wrong");
}

?>
<br><a href=index.phps>index.phps</a>
</body>
</html>
