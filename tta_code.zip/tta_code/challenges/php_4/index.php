<html> 
<head> 
<title>PHP 4</title> 
<style type="text/css"> 
body { background:black; color:white; font-size:10pt; }     
a { color:lightgreen; } 
</style> 
</head> 
<body> 

<?php

if(eregi("admin",$_GET[id])) { echo("<p>access denied"); exit(); } 

$_GET[id]=urldecode($_GET[id]); 

if($_GET[id]=="admin") 
{
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_urlEnc0d225");
	echo("Password is $password");
} 

?> 

<br><br> 
<a href=index.phps>index.phps</a> 
</body> 
</html> 
 
