<html>
<head>
<title>PHP 5</title>
<style type="text/css">
body { background:black; color:white; font-size:10pt; }
a { color:lightgreen; }
</style>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_flagphpPhppHpphPPHP");
$ip=md5($_SERVER[REMOTE_ADDR]);
$val=$$_GET[$ip];
echo(htmlspecialchars($val));
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
