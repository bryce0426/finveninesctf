<html>
<head>
<title>Race</title>
</head>
<body>
<b>Race</b>
<br><a href=index.phps>index.phps</a>
<br>
<?php
sleep(1);

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_weBRac2e~~~");

if($_GET[mode]=="auth")
{
	echo("Auth~<br>");
	$f=@file("readme/$_SERVER[REMOTE_ADDR].txt");
	for($i=0;$i<=strlen($f);$i++)
	{
        	$result.=$f[$i];
        }

	if(eregi("$_SERVER[REMOTE_ADDR]",$result))
	{
		echo("Done!");
 		@unlink("readme/$_SERVER[REMOTE_ADDR].txt");
		echo("Password $password");
		exit();
    }
}


$f=@fopen("readme/$_SERVER[REMOTE_ADDR].txt","w");
@fwrite($f,"$_SERVER[REMOTE_ADDR]");
@fclose($f);

if($_SERVER[REMOTE_ADDR]!="127.0.0.1")
{
	sleep(1);
	@unlink("readme/$_SERVER[REMOTE_ADDR].txt");
}
?>
</body>
</html>
