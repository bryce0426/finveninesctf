<html>
<head>
<style type="text/css">
body { background:black; color:white; font-size:20pt; margin:10pt; padding:10pt; font-family:'fantasy'; }
a { color:green; }
</style>
<title>Reg 1</title>
</head>
<body>
<?php
if(eregi("[0-9][A-D][100-200]{5}",$_GET[reg]))
{
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_regEasy11!!@@");
	echo("Password is $password");
}
?>
<br><a href=index.phps>index.phps</a>
</body>
</html>
