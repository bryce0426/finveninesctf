<html>
<head>
<style type="text/css">
body { background:black; color:white; font-size:20pt; margin:10pt; padding:10pt; font-family:'fantasy'; }
a { color:green; }
</style>
<title>Reg 2</title>
</head>
<body>
<?php
if(eregi("[a-f]{5}.*$_SERVER[REMOTE_ADDR].*\t",$_GET[reg]))
{
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_^dh^regEasy12@2!!@@");
	echo("Password is $password");
}
?>
<br><a href=index.phps>index.phps</a>
</body>
</html>
