<html>
<head>
<title>replace</title>
</head>
<body>
<?php
    $file = $_GET['file'];

    if(!$file)
        $file  = "default.php";

    $file = str_replace("./", "", $file);

    echo(htmlspecialchars($file)."<br>");

    if($file=="default.php") include "files/default.php";
    if($file=="../pw.php")
    {
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_reP1Ac22FLAG@@@");
        echo("<br>Password is $password");
    }
    
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
