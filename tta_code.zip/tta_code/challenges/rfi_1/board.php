<h2>Board</h2>
<table border=1 align=center cellpadding=10 style=width:90%>
<tr onmouseover=this.style.background='silver' onmouseout=this.style.background='white'><td>1</td><td>admin</td><td>board test</td><td>07-31</td></tr>
</table>
<br><br>
<center><a href=#>Write</a></center>
