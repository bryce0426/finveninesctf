<html>
<head>
<style type="text/css">
body { background:silver; margin:0 }
.wrap { width:500pt; height:300pt; background:#F6F6F6; border:1pt solid black; }
.top_menu { width:500pt; background:gray; border-bottom:1pt solid black; text-align:left; }
.main {width:500pt; height:200pt; text-align:left; padding:10pt; }
input { width:20%; background:gray; border:0; }
input:hover { background:#3399FF; color:white; }
.bottom { font-size:9pt; color:blue; }
</style>
<title>RFI 3</title>
</head>
<body><center><br>

<div class=wrap>
	<div class=top_menu>
	<input type=button value='Main' onclick=location.href='?page=main.php'>
        <input type=button value='About' onclick=location.href='?page=about.php'>
        <input type=button value='Board' onclick=location.href='?page=board.php'>
        <input type=button value='Contact' onclick=location.href='?page=contact.php'>
	</div>

	<div class=main>
	<?php

        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_rfi3phpwrapp2R");

	if(substr($_GET[page],0,1)=="/") exit("access denied");
        if(substr($_GET[page],0,1)==".") exit("access denied");

	if(eregi("ftp:|http:|data:|input",$_GET[page])) exit("access denied");

	if(eregi("//",$_GET[page]))
	{
		if(eregi("php://filter/",$_GET[page])){
			if(eregi("base64",$_GET[page])){
				if(eregi("resource",$_GET[page])){
					echo("<h3>Password is $password</h3>");
				}
			}
		}
	}

	/*
	 php://filter/write=convert.base64-decode/resource=/etc/passwd
	*/

	if($_GET[page]=="main.php") include "main.php";
        if($_GET[page]=="about.php") include "about.php";
        if($_GET[page]=="board.php") include "board.php";
        if($_GET[page]=="contact.php") include "contact.php";
		
	?>
	</div>

	<div class=bottom>RFI 3</div>


</div>
</body>
</html>
