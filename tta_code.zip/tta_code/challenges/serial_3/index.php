<?php @session_start(); ?>
<html>
<head>
<title>Serial 3</title>
</head>
<body>
<br><br>
<a href=index.phps>index.phps</a>
<br><br>
<?php
class login
{
	public $id;

	function __destruct()
	{
		$path=str_replace("index.php","",$_SERVER[SCRIPT_FILENAME])."users/";
		$user="{$this->id}";
		if(eregi("/|\.\.|:",$user)) exit("Access Denied");
		$f=@file($path.$user) or die("Not found");
		for($i=0;$i<=5;$i++)
		{
			echo($f[$i]);
		}
	}
}

if($_GET[data]) $user_data = unserialize(base64_decode($_GET['data']));
?>
</body>
</html>
