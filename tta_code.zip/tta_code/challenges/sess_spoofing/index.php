<html>
<head>
<title>sess spoofing</title>
</head>
<body>
<?php
    ini_set("session.save_path","/var/www/challenges/sess_spoofing/sessions/");
    session_start();

    $password=md5("$_SERVER[REMOTE_ADDR]_tiger_sessspo0F1ngFLAG@@");
    $type = $_GET['type'];

    // admin session
    $f=@file("sessions/sess_adminsecretsession");
    if($f[0]!='user_id|s:5:"admin";')
    {
	$f=@fopen("sessions/sess_adminsecretsession","w");
	@fwrite($f,'user_id|s:5:"admin";');
	@fclose($f);
    }


    if($type == "login")
    {
        if($_COOKIE[PHPSESSID]!="adminsecretsession") {$_SESSION['user_id'] = "guest";}
    }

    $user_id = $_SESSION['user_id'];

    if($user_id == "admin")
        echo("Password is $password<br>");
    else if($user_id == "guest")
        echo("hello guest<br>");
    else
        echo("login plz<br>");
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
