#!/bin/sh

echo "setup"
chmod 777 sessions
chgrp www-data sessions
service apache2 restart