<?php header("content-type: text/html;charset=euc-kr");?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
body { background:#363636; color:white; }
p { text-align:center; padding:5pt; font-size:30pt; font-family:fantasy; border-bottom:5pt solid gray; }
.content { font-family:Webdings; font-size:50pt; border:10pt solid yellow;float:lef;margin:5pt; padding:10pt;}
.content:hover { background:white; color:blue; }
.info { color:yellow; text-align:right; font-size:7pt; }
</style>
<title>SHOP 2</title>
</head>
<body>
<div class=info>guest / <?=$_SERVER[REMOTE_ADDR]?><br>point : 10</div>
<p>SHOP 2</p>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_paramete@RcontroLeasy222@@");

if($_GET[buy])
{
	if(eregi("[^0-9]",$_GET[buy])) $_GET[buy]=1;
	$price=10000;
	if($_GET[buy]==1) $price=100000;
        if($_GET[buy]==2) $price=10000;
        if($_GET[buy]==3) $price=50000;
        if($_GET[buy]==4) $price=30000;

	$price=base64_encode($price);

	if($_POST[price] && $_POST[name] && $_POST[address] && $_POST[phone])
	{
		$_POST[price]=base64_decode($_POST[price]);
	        if(eregi("[^0-9]",$_POST[price])) $_POST[price]=100000;
		if($_GET[buy]!=1 && $_GET[buy]!=2 && $_GET[buy]!=3 && $_GET[buy]!=4) exit("error");
		if($_POST[price]>10) exit("not enough money");

		echo("Done!<br><br>Password is $password");
		exit();
	}

	echo("<form method=post action=index.php?buy=$_GET[buy]><input type=hidden name=price value='$price'><table border=0 cellpadding=10 cellspacing=0 align=center><tr><td 
colspan=2 
bgcolor=green>SHOP - 
$_GET[buy]</td></tr><tr><td>name</td><td><input type=text name=name></td></tr><tr><td>address</td><td><input type=text name=address></td></tr><tr><td>phone</td><td><input type=text name=phone></td></tr><tr><td colspan=2 align=center><input type=submit></td></tr></table></form>");

	exit();
}

?>
<div><a class=content onclick=location.href='?buy=1'>H</a>100,000</div><br><br>
<div><a class=content onclick=location.href='?buy=2'>(</a>10,000</div><br><br>
<div><a class=content onclick=location.href='?buy=3'>p</a>50,000</div><br><br>
<div><a class=content onclick=location.href='?buy=4'>M</a>30,000</div><br><br>
</body>
</html>
