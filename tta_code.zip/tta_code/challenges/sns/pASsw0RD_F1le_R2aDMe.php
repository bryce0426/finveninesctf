<?php
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_snschal1leng2passw0rd@");
	echo("Password is $password");
?>
