<html>
<head>
<style type="text/css">
* { margin:0 auto; padding:10pt; }
input[type=submit] { width:150pt; }
</style>
<title>SQL 100</title>
</head>
<body>
<?php
	mysql_connect("localhost","sql100","sql100") or die("* mysql_connect error");
	mysql_select_db("sql100");
	$password=md5("$_SERVER[REMOTE_ADDR]_tiger_sql100clear");
	if($_GET[id] && $_GET[pw])
	{
		// injection point
		$query="select id,pw from user where id='$_GET[id]' and pw='$_GET[pw]'";
		$data=mysql_fetch_array(mysql_query($query));

		if($data[id]=="guest")
		{
			echo("hi guest!");
		}

		else if($data[id]=="admin")
		{
			echo("hi admin!");
			echo("<br>password is $password");
		}

		else
		{
			echo("Wrong<br>".htmlspecialchars($query)."<br>");
		}
	echo("<br><br><a href=index.php>Done</a>");
	exit();
	}
?>

<form method=get action=index.php>
<table border=0 align=center cellpadding=20 cellspacing=0>
<tr><td>username</td><td><input type=text name=id value='guest'></td></tr>
<tr><td>password</td><td><input type=password name=pw value='guest'></td></tr>
<tr><td colspan=2 align=center><input type=submit value='Login'></td></tr>
</table>
</form>
<center><a href=index.phps>index.phps</a></center>
</body>
</html>
