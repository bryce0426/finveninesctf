<html>
<head>
<title>SQL BLIND</title>
<style type="text/css">
* { background:black;border:0;color:lightgreen;padding:10pt;}
</style>
</head>
<body>
<?php
	mysql_connect("localhost","sql_blind","sql_blind");
	mysql_select_db("sql_blind");
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_blinder");

	if($_GET[id] && $_GET[pw])
	{	
		if($_GET[id]=="admin" && $_GET[pw]=="solution") echo("<b>Password is $password<br></b>");

		$q=mysql_fetch_array(mysql_query("select id from user where id='$_GET[id]' and pw='$_GET[pw]'"));

		if($q[id]) echo("Login success");
		else echo("Login failed");
	}
?>
<form method=get action=index.php>
ID : <input type=text name=id value='guest'>
PW : <input type=text name=pw value='guest'><input type=submit><br>
</form>
<a onclick=location.href='index.phps'>index.phps</a>
</body>
</html>
