<html>
<head>
<style type="text/css">
table { width:100%; }
input[type=text] { width:80%; }
</style>
<title>SQL Board</title>
</head>
<body>
<center><h2>BOARD</h2></center><br><br>
<table border=1 align=center cellpadding=10>
<?php
@mysql_connect("localhost","sql_board","sql_board");
@mysql_select_db("sql_board");

if($_GET[no])
{
	$_GET[no]=addslashes($_GET[no]);
	$q=mysql_fetch_array(mysql_query("select * from board where md5(tm)='$_GET[no]'"));
	if(substr($q[sub],0,1)=="*") exit("Access Denied");
        $q[tm]=date('Y-m-d H:i',$q[tm]);
	echo("$q[tm]<br><br><b>id</b><br>$q[id]<br><br><b>sub</b><br>$q[sub]<br><br>$q[memo]<br><br><a href=index.php>back</a>");
	exit();
}

$q=mysql_query("select * from board");
if($_GET[search])
{
	$_GET[search]=addslashes($_GET[search]);
	$q=mysql_query("select * from board where memo like '%$_GET[search]%'");
}
while($d=@mysql_fetch_array($q))
{
	$no=md5($d[tm]);
	$d[tm]=date('Y-m-d H:i',$d[tm]);
	echo("<tr onclick=location.href='?no=$no' onmouseover=this.style.background='silver' onmouseout=this.style.background='white'><td width=50>$d[id]</td><td>$d[sub]</td><td width=200>$d[tm]</td></tr>");
}
echo("</table>");
echo("<br><br><center><form method=get action=index.php><input type=text name=search><input type=submit></center></form>");
?>
<br><br><a href=index.phps>index.phps</a>
</body>
</html>
