<html>
<head>
<style type="text/css">
* { background:black; color:yellow; margin:10pt; font-size:20pt; }
</style>
<title>SQL error 2</title>
</head>
<body>
<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_err0rBASED22@@2");
mysql_connect("localhost","sql_error2","sql_error2") or die("mysql error");
mysql_select_db("sql_error2");

if(!$_GET[id]) $_GET[id]="admin";

$q=@mysql_fetch_array(mysql_query("select pw from mem where id='$_GET[id]'"));
if(mysql_error()) exit();

if(isset($q[pw]) && isset($_GET[pw])){
if($q[pw]==$_GET[pw]) echo("Password is $password");}
?>
<br><a href=index.phps>index.phps</a>
</body>
</html>

