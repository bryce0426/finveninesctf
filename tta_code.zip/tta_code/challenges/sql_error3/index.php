<html>
<head>
<title>SQL error 3</title>
</head>
<body>
<center>
<?php
@mysql_connect("localhost","sql_error3","sql_error3");
@mysql_select_db("sql_error3");
if($_POST[msg])
{
	// select pw from password
	// length(pw) = 15, aA~zZ
	if(eregi("sleep|ben",$_POST[msg])) exit("Access Denied");
	@mysql_query("insert into msg values('$_POST[msg]')") or die(md5(mysql_error()));
	echo("Done<br><br>");
}
?>
<form method=post action=index.php>
<input type=text name=msg><input type=submit>
</form>
<a href=index.phps>index.phps</a>
</center>
</body>
</html>
