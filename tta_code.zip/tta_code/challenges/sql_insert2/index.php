<?php

mysql_connect("localhost","sql_insert2","sql_insert2") or die("error");
mysql_select_db("sql_insert2");

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_sql1nserT2@");

if($_POST[lid] && $_POST[lphone])
{
	$q=@mysql_fetch_array(mysql_query("select id,lv from mem where id='$_POST[lid]' and phone='$_POST[lphone]'"));

	if($q[id])
	{
		echo("id : $q[id]<br>lv : $q[lv]<br><br>");

		if($q[lv]=="admin")
		{
			@mysql_query("delete from mem");
			echo("Password is $password");
		}

		echo("<br><a href=index.php>back</a>");
		exit();
	}
}

if($_POST[id] && $_POST[phone])
{
	if(strlen($_POST[phone])>=20) exit("Access Denied");
	if(eregi("admin",$_POST[id])) exit("Access Denied");
	if(eregi("admin|0x|#|hex|char|ascii|ord|from|select|union",$_POST[phone])) exit("Access Denied");
	@mysql_query("insert into mem values('$_POST[id]',$_POST[phone],'guest')");
}
?>
<html>
<head>
<title>SQL insert 2</title></head><body>
<form method=post action=index.php>
<table border=0 cellpadding=10 cellspacing=0>
<tr bgcolor=silver><td>Register</td><td><input name=id></td><td><input name=phone></td><td><input type=submit></td></tr>
<tr bgcolor=gray><td>Login</td><td><input name=lid></td><td><input name=lphone></td><td><input type=submit></td></tr>
</table>
<br><a href=index.phps>index.phps</a>
</form>
</body></html>
