<?php
mysql_connect("localhost","sql_insert3","sql_insert3");
mysql_select_db("sql_insert3");

$password=md5("$_SERVER[REMOTE_ADDR]_tiger_1nserTS0LINjection~~");


foreach($_POST as $no=>$val)
{
	if(ini_get("magic_quotes_gpc")!=1) $_POST[$no]=addslashes($val);
}

if($_GET[mode]=="login")
{
	if($_POST[id] && $_POST[pw])
	{
		$_POST[pw]=md5($_POST[pw]);

		$q=@mysql_fetch_array(mysql_query("select id from mem where id='$_POST[id]' and pw='$_POST[pw]'"));

		if($q)
		{
			echo("hi ".htmlspecialchars($q[id])."!<br><br>");
			if($q[id]=="admin")
			{
				echo("<b>Password is $password</b><br>");
				@mysql_query("delete from mem");
			}
			exit();
		}

	}
	echo("<h1>Login</h1> <h1><a href=?mode=register>Register</a></h1><br><hr><form method=post action=index.php?mode=login>ID<br><input type=text name=id><br><br>PW<br><input type=text name=pw><br><br><input 
type=submit></form>");
}

else
{
	if($_POST[id] && $_POST[pw])
	{
		$_POST[pw]=md5($_POST[pw]);
		if($_POST[id]=="admin") exit("Acces Denied");
		$q=@mysql_fetch_array(mysql_query("select id from mem where id='$_POST[id]'"));
		if(!$q)
		{
			@mysql_query("insert into mem(id,pw) values('$_POST[id]','$_POST[pw]')");
			echo("Done<br><br>");
		}
	}
	echo("<h1>Register</h1> <h1><a href=?mode=login>Login</a></h1><br><hr><form method=post action=index.php?mode=register>ID<br><input type=text name=id><br><br>PW<br><input type=text name=pw><br><br><input 
type=submit></form>");
}
?>
<hr><a href=index.phps>index.phps</a><hr>
