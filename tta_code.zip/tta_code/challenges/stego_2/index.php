<html>
<head>
<title>Stego 2</title>
</head>
<body>
<center>
<br><b>Stego_2</b><br><br>
<img src="hackme_2.png?password=<?=base64_encode('24680')?>" width=50 height=50>
</body>
</html>
