<html>
<head>
<style type="text/css">
body { background:black; color:lightgreen; margin:0;padding:10pt; }
input { background:black; border:1pt solid white; color:white; }
</style>
<title>system</title>
</head>
<body>
<?php
if($_POST[name])
{
	$ip=md5("$_SERVER[REMOTE_ADDR]_$_SERVER[REMOTE_ADDR]_$_SERVER[REMOTE_ADDR]");
	$go=$_POST[name];
	$go=substr($go,0,5);
	system("echo 'hello! $go' > result/$ip.txt");

	echo("<meta http-equiv=refresh content=0;url='result/$ip.txt'>");
	exit();
}
?>
<form method=post action=index.php>
name<br><br><input name=name type=text maxlength=5><input type=submit value='Submit'>
</form>
</body>
</html>
