<html>
<head>
<title>uploader</title>
</head>
<body>
<?php
mysql_connect("localhost","uploader","uploader");
mysql_select_db("uploader");

if($_FILES['upfile'])
{
	$tm=time();
	$i=0;
	$fn=$_FILES['upfile']['name'];
	$fn=htmlspecialchars($fn);

	@mysql_query("insert into pds(ip,file,tm) values('$_SERVER[REMOTE_ADDR]','$fn','$tm')") or die("upload error");
}

	$q=mysql_query("select * from pds where ip='$_SERVER[REMOTE_ADDR]' order by tm desc");
	echo("<table border=0 align=center cellpadding=10 style=width:100%>");

	while($d=mysql_fetch_array($q))
	{
		echo("<tr onmouseover=this.style.background='silver' onmouseout=this.style.background='white' ><td>$d[tm]</td><td>$d[ip]</td><td>$d[file]</td></tr>");
		$i++;
	}
	echo("<tr><td colspan=3 align=center>$i/100</td></tr>");
	if($i>=100) mysql_query("delete from pds where ip='$_SERVER[REMOTE_ADDR]'");
?>
</table>
<form method=post action=index.php enctype=multipart/form-data>
<input type=file name=upfile><input type=submit>
</form>
<a href=index.phps>index.phps</a>
</body>
</html>
