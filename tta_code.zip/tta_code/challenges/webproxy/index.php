<?php
$password=md5("$_SERVER[REMOTE_ADDR]_tiger_webpr0XYY");
header("password: $password");
?>
<html>
<head>
<style type="text/css">
body { background:silver; color:black; margin:0 auto;padding:20pt;font-weight:bold;font-size:50pt; }
</style>
<title>Webproxy</title>
</head>
<body>
paros, fiddler, burp suite . . .
</body>
</html>
