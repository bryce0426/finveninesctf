<?php 
session_start();
header('X-XSS-Protection: 0');


if(!$_GET[token])
{
	exit("ACCESS DENIED");
}

if($_GET[token])
{
	for($i=time()-60;$i<=time();$i++)
	{
		$token = sha1("$_SERVER[REMOTE_ADDR]_hehe!sheshe2".$i);
		if($_GET[token]==$token) $check="true";
	}

	if($check!="true") exit("ACCESS DENIED");

}

if(!$_SESSION[xss_challenge])
{
	$_SESSION[xss_challenge]=1;
	exit("<meta http-equiv=refresh content=0;url=game.php>");
}

if($_GET[refresh]==1) exit("<meta http-equiv=refresh content=0;url=game.php>"); ?>
<html>
<head>
<link rel="stylesheet" href="style.css" type="text/css">
<script src="script.js"></script>
<title>XSS 3</title>
</head>
<body>
<?php
if(!$_POST[name])
{
echo("<br><br>
<form method=post action=game.php?token=$token>
<center>
NAME<br><br>
<input type=text name=name><br><br><input type=submit>
</center>
</form>
");
}

if($_POST[name])
{
	if(eregi("\(|\)|:| |!",$_POST[name])) exit("Access Denied");
	echo("RESULT<br><br><input type=button value='$_POST[name]'>");
}

?>
</body>
</html>
