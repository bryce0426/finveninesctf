<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="script.js"></script>
<title>XXE</title>
</head>
<body>
<div style=background:gray;margin:0;padding:10pt;text-align:center;>
<script>document.write(sender("hi <?=$_SERVER[REMOTE_ADDR]?>"));</script>
</div>
</body>
</html>
