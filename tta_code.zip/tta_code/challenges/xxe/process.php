<?php
function customError($errno, $errstr)
 { 
// echo "<p><strong>Error:</strong> [$errno] $errstr</p>\n";
 }

set_error_handler("customError");

if($_POST['q'])
{
        $password=md5("$_SERVER[REMOTE_ADDR]_tiger_xmlXX2@systemENtity");
	$q=stripslashes($_POST['q']);
	$xml=@simplexml_load_string($q);
	$xml=htmlspecialchars($xml);

	if(eregi("<!DOCTYPE ",$_POST['q'])){
	if(eregi("<!ENTITY ",$_POST['q'])){
	if(eregi("SYSTEM",$_POST['q'])){
		echo("Password is $password");
		exit();
	}}}

	else echo("$xml");
}
?>
