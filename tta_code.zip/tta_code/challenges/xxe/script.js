function sender(val)
{
	var x = new XMLHttpRequest();
	data='q=<'+'?xml version="1.0"?><menu>'+val+'</menu>';
	x.open('POST','process.php',false);
	x.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	x.setRequestHeader('Content-Length',data.length);
	x.send(data);
	return x.responseText;
}
