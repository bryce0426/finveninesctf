<script src="js/jquery.tools.min.js"></script>
<?php if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();

getinfo($_SESSION[id]);

if($_POST[c_flag])
{
	sleep(1);
	$_SESSION[id]=sql_guard($_SESSION[id]);
	$probs=getprobs($_SESSION[id]);
	$flag=htmlspecialchars($_POST[c_flag]);

	if(strlen($flag)!=32) $flag=md5("$_SERVER[REMOTE_ADDR]_tiger_$flag");

	$flag=trim($flag);
	$flag=strtolower($flag);
	$q=mysql_query("select reg_no,reg_name,reg_score,reg_flag from tbl_probs where reg_type<>'hidden' order by reg_no asc");
	while($d=mysql_fetch_array($q))
	{
		if($flag==md5("$_SERVER[REMOTE_ADDR]_tiger_$d[reg_flag]"))
		{
			$tm=time();
			if($probs["reg_prob".$d[reg_no]]) {echo("<p id=error>�̹� Ŭ�����Ͻ� �����Դϴ�.</p>"); break; }
			else{
			echo("<p id=msg>�����մϴ� $d[reg_name] ������ Ŭ���� �߽��ϴ�.<br>$d[reg_score] ����Ʈ�� ȹ��</p>");
			@mysql_query("update tbl_user_probs set reg_prob".$d[reg_no]."=$tm where reg_id='$_SESSION[id]'");
			@mysql_query("update tbl_user_probs set reg_score=reg_score+$d[reg_score] where reg_id='$_SESSION[id]'");
			@mysql_query("update tbl_user_probs set reg_auth='$tm' where reg_id='$_SESSION[id]'");
			@mysql_query("insert into tbl_clear_log(reg_time,reg_id,reg_prob,reg_ip) values('$tm','$_SESSION[id]','$d[reg_name]','$_SERVER[REMOTE_ADDR]')");
			break;
			}
		}
	}
}
$i=1;

if(!$_GET[order]) $order="reg_no asc";
if(!$order) $order="reg_no asc";

$query_all=@mysql_query("select * from tbl_probs where reg_type<>'hidden' order by $order");
$c_all=challenge($query_all);

$challenge_q=@mysql_query("select * from tbl_probs_category");

?>

<p align="center"><img src="images/common/Title_challenges.png" border="0" width="500" height="70"></p>
                                    </td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="1000" align="center">
                                <tr>
                                    <td width="1000" height="10"></td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="1000" height="450" valign="top">
                                        <div id=challenges>
<p align="center">
<input type=button onclick=c_view('ALL',this); value='ALL'id=c style="background:url('images/challenges/all_1.png');width:131;height:43;border:0;cursor:hand"><?php
while($dd=mysql_fetch_array($challenge_q))
{
	$dd[reg_type]=strtoupper($dd[reg_type]);
	echo("<input type=button style=background:url('images/challenges/b_1.png');width:131;height:43;border:0;cursor:hand;margin:1pt; value='$dd[reg_description]' id=c onmouseover=this.style.background=\"url:('images/challenges/b_2.png')\" onclick=c_view('$dd[reg_type]',this)>");
}
?>
</p>
		<?php
		if($_GET[user])
		{
			echo("<p id=msg>".htmlspecialchars($_GET[user])."���� ����Ǯ�� ��Ȳ</p>");
		}
		?>
<div id=challenges_all>
                <div style=padding:5pt;>
		<?=$c_all?>
                </div>
        </div>

<?php

$challenge_q=@mysql_query("select * from tbl_probs_category");

while($d=@mysql_fetch_array($challenge_q))
{
	if(!$_GET[order]) $order="reg_no asc";
	if(!$order) $order="reg_no asc";

	$q=@mysql_query("select * from tbl_probs where reg_type='$d[reg_type]' order by $order");
	echo("<div style=display:none; id=challenges_$d[reg_type]><div style=padding:5pt;>".challenge(mysql_query("select * from tbl_probs where reg_type='$d[reg_type]' order by $order"))."</div></div>");
}

?>
<!--
	<div id=challenges_all>
		<div style=padding:5pt;>
		</div>
	</div>

	<div style=display:none; id=challenges_sql>
		<div style=padding:5pt;>
		<?=$c_sql?>
		</div>
	</div>

	<div style=display:none; id=challenges_xss>
		<div style=padding:5pt;>
		<?=$c_xss?>
		</div>
	</div>

	<div style=display:none; id=challenges_fi>
		<div style=padding:5pt;>
		<?=$c_fi?>
		</div>
	</div>

	<div style=display:none; id=challenges_fu>
		<div style=padding:5pt;>
		<?=$c_fu?>
		</div>
	</div>

	<div style=display:none; id=challenges_code>
		<div style=padding:5pt;>
		<?=$c_code?>
		</div>
	</div>

	<div style=display:none; id=challenges_etc>
		<div style=padding:5pt;>
		<?=$c_etc?>
		</div>
	</div>
-->
</div>
<script>challenge();</script>
