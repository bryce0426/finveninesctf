<?php
if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();

echo("<div id=msg>����Ǯ�� ��Ȳ<br>");

$q=mysql_query("select * from tbl_clear_log order by reg_time desc,reg_prob asc limit 0,10");

while($d=mysql_fetch_array($q))
{
	$tm=date('Y-m-d H:i',$d['reg_time']);
	echo("&lt;$d[reg_prob]&gt;$tm $d[reg_id]");
}

echo("</div>");
?>
