<?php if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit(); ?>
                                                    <p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_research.png" width="500" height="60" border="0"></p>
						<table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="68">
                                                                <p><img src="images/common/bar_research_paper.png" width="960" height="68" border="0"></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;"><a href=downloads/how_to_sql_injection.pdf class=download>how to sql 
injection</a></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                   	 <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;"><a href=downloads/xss.pdf class=download>xss</a></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
													 <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;"><a href=downloads/xss.pdf class=download>csrf</a></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
													 <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;"><a href=downloads/xss.pdf class=download>blind sql injection</a></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>
													<table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="20">
                                                            </td>
                                                        </tr>
                                                    </table>
													<table align="center" cellpadding="0" cellspacing="0" width="960">
                                                        <tr>
                                                            <td width="960" height="68">
                                                                <p><img src="images/common/bar_research_etc.png" width="960" height="68" border="0"></p>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <table align="center" cellpadding="0" cellspacing="0" width="960" background="images/common/bar_bg2.png">
                                                        <tr>
                                                            <td width="960" height="37">
                                                                <p align="center"><font color="white"><span style="font-size:10pt;"><a href='#' class=download>test</a></span></font></p>
                                                            </td>
                                                        </tr>
                                                    </table>

                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
