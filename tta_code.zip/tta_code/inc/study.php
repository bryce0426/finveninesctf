<?php if(strstr($_SERVER[PHP_SELF],"index")!="index.php")  exit();?>
<p style="margin-top:5; margin-bottom:5;" align="center"><img src="images/common/Title_study.png" width="500" height="60" border="0"></p>
</td></tr><tr><td>
                                                    <p align="center"><img src="images/study/study.png" width="596" height="114" border="0"></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="990" height="57">
                                                    <p align="center"><img src="images/study/Btn_make.png" width="132" height="28" border="0" onclick=location.href='?page=forum&id=<?=$_SESSION[id]?>'></p>
                                                </td>
</tr>
