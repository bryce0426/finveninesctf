<?php
header("Content-Type: text/html; charset=euc-kr");
@session_start();
include "inc/conn.php";

if($_SESSION[id] && !$_SESSION[ip])
{
	$_SESSION[ip] = $_SERVER[REMOTE_ADDR];
}

if($_SESSION[id] && $_SESSION[ip] && $_SESSION[ip]!=$_SERVER[REMOTE_ADDR])
{
	exit("Wrong ip");
}

$msg_ck=msg_check($_SESSION[id]);
if($msg_ck>0)
{
	echo("<br><div align=right onclick=location.href='?page=msg'><font color=yellow size=3>[!]</font><font size=3 color=lightgreen>�޼����� �����߽��ϴ� (".$msg_ck."��)</div><br>");
}
?>
<html>
<head>
<title>::Tiger Team Academy::</title>
<META NAME="Generator" CONTENT="EditPlus">
<link rel=stylesheet href="css/style.css" type="text/css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
	<script src="css/slides.min.jquery.js"></script>
	<script type="text/javascript" src="js/comm.js"></script>
</head>

<body text="black" link="blue" vlink="purple" alink="red" leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" bgcolor="black">
<div id="wrapper">
<table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td valign="top">
                <table cellpadding="0" cellspacing="0" width="1000" align="center">
                    <tr>
                        <td width="1000" height="50"><a href="?page=about"><img src="images/Btn/Btn_01.png" 
onmouseover='this.src="images/Btn/Btn_over_01.png"' onmouseout='this.src="images/Btn/Btn_01.png"' style="cursor:hand" border="0"></a><a 
href="?page=challenges"><img src="images/Btn/Btn_02.png" onmouseover='this.src="images/Btn/Btn_over_02.png"' 
onmouseout='this.src="images/Btn/Btn_02.png"' style="cursor:hand" border="0"></a><a href="?page=rank"><img src="images/Btn/Btn_03.png" 
onmouseover='this.src="images/Btn/Btn_over_03.png"'
onmouseout='this.src="images/Btn/Btn_03.png"' style="cursor:hand" border="0"></a>
<?php
if($_SESSION[id])
{
?>
<a href="?page=login"><img src="images/Btn/Btn_09.png" 
onmouseover='this.src="images/Btn/Btn_over_09.png"' 
onmouseout='this.src="images/Btn/Btn_09.png"' style="cursor:hand" border="0"></a>
<? } if(!$_SESSION[id]) {?>
<a href="?page=login"><img src="images/Btn/Btn_10.png" onmouseover='this.src="images/Btn/Btn_over_10.png"' 
onmouseout='this.src="images/Btn/Btn_10.png"' style="cursor:hand" border="0"></a>
<? } ?>
</td>
                    </tr>
                </table>

				<table cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td width="100">
                            <table cellpadding="0" cellspacing="0" width="1000" align="center">
                                <tr>
                                    <td width="1000">

<!-- Menu -->
<?php
		switch($_GET[page])
		{
			case "about":{
				include "inc/about.php";
				break;
			}
			case "challenges":{
				include "inc/challenges.php";
				break;
			}
			case "rank":{
				include "inc/rank.php";
				break;
			}

			case "login":{
				include "inc/login.php";
				break;
			}

			default:{
				include "inc/about.php";
			}
		}
		?>
<!-- Menu -->
</table>
                            <table cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td width="1000" height="20">&nbsp;</td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="100%">
                                <tr>
                                    <td width="100" height="20" bgcolor="#363636"></td>
                                </tr>
                            </table>
                            <table cellpadding="0" cellspacing="0" width="1000" align="center">
                                <tr>
                                    <td width="1000">
                                        <p align="center" 
style="margin-top:5pt; margin-bottom:5pt;"><font color="white"><span style="font-size:9pt;">Copyright 2014 TigerTeam Co.,Ltd. All rights Reserved.</span></font>   </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
	</td>
</tr>
</table>
</div>

</body>
</html>
