export LC_ALL="ko_KR.eucKR"
export LANG="ko_KR.eucKR"
